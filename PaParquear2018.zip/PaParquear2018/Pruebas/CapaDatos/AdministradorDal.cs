﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace CapaDatos
{
     public class AdministradorDal
    {
        public DataTable getUsuariosDal(int identificacion)
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            //Creamos un objeto de tipo dataset o datatable
            DataTable dtUsuarios = new DataTable();

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@identificacion", identificacion));
            objComando.CommandText = "getAllUsuarios";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtUsuarios);
            //cerramos la Conexion
            Conexion.Close();

            return dtUsuarios;

        }
        public DataTable getClientesDal(int identificacion)
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            //Creamos un objeto de tipo dataset o datatable
            DataTable dtUsuarios = new DataTable();

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@identificacion", identificacion));
            objComando.CommandText = "getAllClientes";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtUsuarios);
            //cerramos la Conexion
            Conexion.Close();

            return dtUsuarios;

        }
        public DataTable getTodosLosUsuariosDal(int identificacion)
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            //Creamos un objeto de tipo dataset o datatable
            DataTable dtUsuarios = new DataTable();

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@identificacion", identificacion));
            objComando.CommandText = "getTodosLosUsuarios";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtUsuarios);
            //cerramos la Conexion
            Conexion.Close();

            return dtUsuarios;

        }

        public DataTable MostrarTodosUsuariosDal()
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            //Creamos un objeto de tipo dataset o datatable
            DataTable dtUsuarios = new DataTable();

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "MostrarTodosUsuarios";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtUsuarios);
            //cerramos la Conexion
            Conexion.Close();

            return dtUsuarios;

        }

        public DataTable getAllIngresosDal()
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            //Creamos un objeto de tipo dataset o datatable
            DataTable dtUsuarios = new DataTable();

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getAllIngresos";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtUsuarios);
            //cerramos la Conexion
            Conexion.Close();

            return dtUsuarios;
        }

        public string Insertar_VigilantesDal(string identificacion, string Nom_Usuario, string Apelli_Usuario, string Dir_Usuario,
            string Tel_Usuario, int id_rol, string Contraseña, string Correo_Elect, int Turno, string PreguntaSeg, string RespuestaSeg, 
            int Estado)
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar 
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            //objComando.Parameters.Add(new SqlParameter("@id_Usuario", Id));
            objComando.Parameters.Add(new SqlParameter("@Identificacion", identificacion));
            objComando.Parameters.Add(new SqlParameter("@Nom_Usuario", Nom_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Apelli_Usuario", Apelli_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Dir_Usuario", Dir_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Tel_Usuario", Tel_Usuario));
            objComando.Parameters.Add(new SqlParameter("@id_Rol", id_rol));
            objComando.Parameters.Add(new SqlParameter("@Contraseña", Contraseña));
            objComando.Parameters.Add(new SqlParameter("@Correo", Correo_Elect));
            objComando.Parameters.Add(new SqlParameter("@Turno", Turno));
            objComando.Parameters.Add(new SqlParameter("@PreguntaSeg", PreguntaSeg));
            objComando.Parameters.Add(new SqlParameter("@RespuestaSeg", RespuestaSeg));
            objComando.Parameters.Add(new SqlParameter("@Estado", Estado));

            objComando.CommandText = "InsertarVigilante";

            //abrir conexion 
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";
        }

        public string Insertar_AdminSupervisorDal(string identificacion, string Nom_Usuario, string Apelli_Usuario, string Dir_Usuario,
            string Tel_Usuario, int id_rol, string Contraseña, string Correo_Elect, string PreguntaSeg, string RespuestaSeg,int Estado)
        {
            //crear un objeto de tipo conexion 
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar 
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            //objComando.Parameters.Add(new SqlParameter("@id_Usuario", Id));
            objComando.Parameters.Add(new SqlParameter("@Identificacion", identificacion));
            objComando.Parameters.Add(new SqlParameter("@Nom_Usuario", Nom_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Apelli_Usuario", Apelli_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Dir_Usuario", Dir_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Tel_Usuario", Tel_Usuario));
            objComando.Parameters.Add(new SqlParameter("@id_Rol", id_rol));
            objComando.Parameters.Add(new SqlParameter("@Contraseña", Contraseña));
            objComando.Parameters.Add(new SqlParameter("@Correo", Correo_Elect));
            objComando.Parameters.Add(new SqlParameter("@PreguntaSeg", PreguntaSeg));
            objComando.Parameters.Add(new SqlParameter("@RespuestaSeg", RespuestaSeg));
            objComando.Parameters.Add(new SqlParameter("@Estado", Estado));

            objComando.CommandText = "InsertarAdminSupervisor";

            //abrir conexion 
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";
        }

        public string AutoRegistro(string identificacion, string Nom_Usuario, string Apelli_Usuario, string Dir_Usuario,
            string Tel_Usuario, int id_rol, string Contraseña, string Correo_Elect, string PreguntaSeg, string RespuestaSeg,
            int Estado, string Matricula, string Modelo, string Color)
        {
            //crear un objeto de tipo conexion 
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            //objComando.Parameters.Add(new SqlParameter("@id_Usuario", Id));
            objComando.Parameters.Add(new SqlParameter("@identificacion", identificacion));
            objComando.Parameters.Add(new SqlParameter("@Nom_Usuario", Nom_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Apelli_Usuario", Apelli_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Dir_Usuario", Dir_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Tel_Usuario", Tel_Usuario));
            objComando.Parameters.Add(new SqlParameter("@id_Rol", id_rol));
            objComando.Parameters.Add(new SqlParameter("@Contraseña", Contraseña));
            objComando.Parameters.Add(new SqlParameter("@Correo", Correo_Elect));
            objComando.Parameters.Add(new SqlParameter("@PreguntaSeg", PreguntaSeg));
            objComando.Parameters.Add(new SqlParameter("@RespuestaSeg", RespuestaSeg));
            objComando.Parameters.Add(new SqlParameter("@Estado", Estado));
            objComando.Parameters.Add(new SqlParameter("@Matricula_Vehi", Matricula));
            objComando.Parameters.Add(new SqlParameter("@Modelo_Vehi", Modelo));
            objComando.Parameters.Add(new SqlParameter("@Color_Vehi", Color));

            objComando.CommandText = "AutoRegistro";

            //abrir conexion 
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";
        }

        public DataTable BuscarPorIdentificaionDal(string identificacion)
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            //Creamos un objeto de tipo dataset o datatable
            DataTable dtUsuarios = new DataTable();

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@identificacion", identificacion));
            objComando.CommandText = "BuscarPorIdentificacion";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtUsuarios);
            //cerramos la Conexion
            Conexion.Close();

            return dtUsuarios;
        }

        public DataTable getIngresoByMatriculaDal(int Placa)
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            //Creamos un objeto de tipo dataset o datatable
            DataTable dtUsuarios = new DataTable();

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Matricula", Placa));
            objComando.CommandText = "getIngresoByMatriculaDal";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtUsuarios);
            //cerramos la Conexion
            Conexion.Close();

            return dtUsuarios;
        }

        public DataTable ConsultaRapidaIngresosDal()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtUsuarios = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "AdminConsultaRapidaIngresos"; //nombre del procedimientpo almacenado

            SqlDataAdapter objAdaptador = new SqlDataAdapter((SqlCommand)objComando);

            //abrir conexion
            Conexion.Open();
            objAdaptador.Fill(dtUsuarios);
            Conexion.Close();

            return dtUsuarios;
        }
        public DataTable ConsultaRapidaIngresosMesDal()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtUsuarios = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "AdminConsultaRapidaIngresosMes"; //nombre del procedimientpo almacenado

            SqlDataAdapter objAdaptador = new SqlDataAdapter((SqlCommand)objComando);

            //abrir conexion
            Conexion.Open();
            objAdaptador.Fill(dtUsuarios);
            Conexion.Close();

            return dtUsuarios;
        }
        public DataTable ConsultaRapidaIngresosHoyDal()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtUsuarios = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "AdminConsultaRapidaIngresosHoy"; //nombre del procedimientpo almacenado

            SqlDataAdapter objAdaptador = new SqlDataAdapter((SqlCommand)objComando);

            //abrir conexion
            Conexion.Open();
            objAdaptador.Fill(dtUsuarios);
            Conexion.Close();

            return dtUsuarios;
        }

        public DataTable ValidarIdentificacion(string identificacion)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            // un objeto de tipo comando que nos va indicar que tipo de consulta va a 
            DataTable dtValidacionI = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            objComando.Parameters.Add(new SqlParameter("@Identificacion", identificacion));
            objComando.CommandText = "NoExistaIdent";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtValidacionI);
            //cerramos la Conexion
            Conexion.Close();

            return dtValidacionI;
        }
        public DataTable ValidarTelefono(string Tel_Usuario)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            // un objeto de tipo comando que nos va indicar que tipo de consulta va a 
            DataTable dtValidacionT = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            objComando.Parameters.Add(new SqlParameter("@Telefono", Tel_Usuario));
            objComando.CommandText = "ValidacionTel";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtValidacionT);
            //cerramos la Conexion
            Conexion.Close();

            return dtValidacionT;
        }


        public string Modificar_UsuariosDal(string Identificacion, string Dir_Usuario,
            string Tel_Usuario, string Contraseña, string Correo_Elect, string PreguntaSeg, string RespuestaSeg,
            string Matricula, string Modelo, string Color)

        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Identificacion", Identificacion));
            objComando.Parameters.Add(new SqlParameter("@Dir_Usuario", Dir_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Tel_Usuario", Tel_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Contraseña", Contraseña));
            objComando.Parameters.Add(new SqlParameter("@Correo", Correo_Elect));
            objComando.Parameters.Add(new SqlParameter("@PreguntaSeg", PreguntaSeg));
            objComando.Parameters.Add(new SqlParameter("@RespuestaSeg", RespuestaSeg));
            objComando.Parameters.Add(new SqlParameter("@Matricula_Vehi", Matricula));
            objComando.Parameters.Add(new SqlParameter("@Modelo_Vehi", Modelo));
            objComando.Parameters.Add(new SqlParameter("@Color_Vehi", Color));

            objComando.CommandText = "Modificar_Usuarios";

            //abrir conexion 
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";

        }

        public string Modificar_VigilantesDal(string Identificacion, string Dir_Usuario,
            string Tel_Usuario, string Contraseña, string Correo_Elect, int Turno, string PreguntaSeg, string RespuestaSeg)
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Identificacion", Identificacion));
            objComando.Parameters.Add(new SqlParameter("@Dir_Usuario", Dir_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Tel_Usuario", Tel_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Contraseña", Contraseña));
            objComando.Parameters.Add(new SqlParameter("@Correo", Correo_Elect));
            objComando.Parameters.Add(new SqlParameter("@Turno", Turno));
            objComando.Parameters.Add(new SqlParameter("@PreguntaSeg", PreguntaSeg));
            objComando.Parameters.Add(new SqlParameter("@RespuestaSeg", RespuestaSeg));

            objComando.CommandText = "Modificar_Vigilantes";

            //abrir conexion 
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";

        }

        public string Modificar_SupervisoresDal(string Identificacion, string Dir_Usuario,
            string Tel_Usuario, string Contraseña, string Correo_Elect, string PreguntaSeg, string RespuestaSeg)
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Identificacion", Identificacion));
            objComando.Parameters.Add(new SqlParameter("@Dir_Usuario", Dir_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Tel_Usuario", Tel_Usuario));
            objComando.Parameters.Add(new SqlParameter("@Contraseña", Contraseña));
            objComando.Parameters.Add(new SqlParameter("@Correo", Correo_Elect));
            objComando.Parameters.Add(new SqlParameter("@PreguntaSeg", PreguntaSeg));
            objComando.Parameters.Add(new SqlParameter("@RespuestaSeg", RespuestaSeg));

            objComando.CommandText = "Modificar_Supervisores";

            //abrir conexion 
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";

        }

        public string Eliminar_Usuarios(int id_Usuarios)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@id_Usuarios", id_Usuarios));
            objComando.CommandText = "Eliminar_Usuarios";
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";

        }
        public DataTable llenarUsuarios()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtUsuarios = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "llenarUsuarios"; //nombre del procedimientpo almacenado

            SqlDataAdapter objAdaptador = new SqlDataAdapter((SqlCommand)objComando);

            //abrir conexion
            Conexion.Open();
            objAdaptador.Fill(dtUsuarios);
            Conexion.Close();

            return dtUsuarios;
        }

        public DataTable getAllRestriccionesDal()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtUsuarios = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getAllRestricciones"; //nombre del procedimientpo almacenado

            SqlDataAdapter objAdaptador = new SqlDataAdapter((SqlCommand)objComando);

            //abrir conexion
            Conexion.Open();
            objAdaptador.Fill(dtUsuarios);
            Conexion.Close();

            return dtUsuarios;
        }
        public DataTable getRestriccionesActivasDal()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtUsuarios = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getAllRestriccionesActivas"; //nombre del procedimientpo almacenado

            SqlDataAdapter objAdaptador = new SqlDataAdapter((SqlCommand)objComando);

            //abrir conexion
            Conexion.Open();
            objAdaptador.Fill(dtUsuarios);
            Conexion.Close();

            return dtUsuarios;
        }

        public DataTable ConsultaRapidaSupervisoresDal()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtUsuarios = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "AdminConsultaRapidaSupervisores"; //nombre del procedimientpo almacenado

            SqlDataAdapter objAdaptador = new SqlDataAdapter((SqlCommand)objComando);

            //abrir conexion
            Conexion.Open();
            objAdaptador.Fill(dtUsuarios);
            Conexion.Close();

            return dtUsuarios;
        }
        public DataTable ConsultaRapidaVigilantesDal()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtUsuarios = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "AdminConsultaRapidaVigilantes"; //nombre del procedimientpo almacenado

            SqlDataAdapter objAdaptador = new SqlDataAdapter((SqlCommand)objComando);

            //abrir conexion
            Conexion.Open();
            objAdaptador.Fill(dtUsuarios);
            Conexion.Close();

            return dtUsuarios;
        }
        public DataTable ConsultaRapidaClientesDal()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtUsuarios = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "AdminConsultaRapidaClientes"; //nombre del procedimientpo almacenado

            SqlDataAdapter objAdaptador = new SqlDataAdapter((SqlCommand)objComando);

            //abrir conexion
            Conexion.Open();
            objAdaptador.Fill(dtUsuarios);
            Conexion.Close();

            return dtUsuarios;
        }

        public DataTable ConsultaRapidaRestriccionesDal()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtUsuarios = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "AdminConsultaRapidaRestricciones"; //nombre del procedimientpo almacenado

            SqlDataAdapter objAdaptador = new SqlDataAdapter((SqlCommand)objComando);

            //abrir conexion
            Conexion.Open();
            objAdaptador.Fill(dtUsuarios);
            Conexion.Close();

            return dtUsuarios;
        }
        public DataTable ConsultaRapidaSancionesDal()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtUsuarios = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "AdminConsultaRapidaSanciones"; //nombre del procedimientpo almacenado

            SqlDataAdapter objAdaptador = new SqlDataAdapter((SqlCommand)objComando);

            //abrir conexion
            Conexion.Open();
            objAdaptador.Fill(dtUsuarios);
            Conexion.Close();

            return dtUsuarios;
        }
    }
}
