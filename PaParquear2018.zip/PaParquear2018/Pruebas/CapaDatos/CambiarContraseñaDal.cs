﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace CapaDatos 
{
    public class CambiarContraseñaDal
    {
        public string UpdateContraseñaDal(int identificacion, string Contraseña)

        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@identificacion", identificacion));
            objComando.Parameters.Add(new SqlParameter("@Contraseña", Contraseña));
            objComando.CommandText = "ModificarContraseña";

            //abrir conexion 
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";
        }

    }

}
