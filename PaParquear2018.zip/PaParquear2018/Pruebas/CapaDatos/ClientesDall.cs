﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace CapaDatos 
{
    public class ClientesDall
    {
        public string ObtenerClientesDal(string Nombres, string Apellidos, string NumeroDocumento, string Direccion, string Telefono)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
           
            objComando.Parameters.Add(new SqlParameter("@Nom_Clie", Nombres));
            objComando.Parameters.Add(new SqlParameter("@Apelli_Clie", Apellidos));
            objComando.Parameters.Add(new SqlParameter("@identificacion", NumeroDocumento));
            objComando.Parameters.Add(new SqlParameter("@Dir_Clie", Direccion));
            objComando.Parameters.Add(new SqlParameter("@Tel_Clie", Telefono));
            objComando.CommandText = "ObtenerCliente";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }

        public string Insertar_ClientesDal(string identificacion, string Nom_Clie, string Apelli_Clie, string Dir_Clie,
            string Tel_Clie, string Correo_Elect)
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            //objComando.Parameters.Add(new SqlParameter("@id_Usuario", Id));
            objComando.Parameters.Add(new SqlParameter("@Identificacion", identificacion));
            objComando.Parameters.Add(new SqlParameter("@Nom_Clie", Nom_Clie));
            objComando.Parameters.Add(new SqlParameter("@Apelli_Clie", Apelli_Clie));
            objComando.Parameters.Add(new SqlParameter("@Dir_Clie", Dir_Clie));
            objComando.Parameters.Add(new SqlParameter("@Tel_Clie", Tel_Clie));
            objComando.Parameters.Add(new SqlParameter("@Correo_Clie", Correo_Elect));
            objComando.CommandText = "Insertar_Clientes";

            //abrir conexion 
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";
        }


        public string Modificar_ClienesDal(string identificacion, string Nom_Clie, string Apelli_Clie, string Dir_Clie,
            string Tel_Clie, string Correo_Elect)
        {

            {
                //crear un objeto de tipo conexion
                SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

                // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
                IDbCommand objComando = Conexion.CreateCommand();
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.Add(new SqlParameter("@Identificacion", identificacion));
                objComando.Parameters.Add(new SqlParameter("@Nom_Clie", Nom_Clie));
                objComando.Parameters.Add(new SqlParameter("@Apelli_Clie", Apelli_Clie));
                objComando.Parameters.Add(new SqlParameter("@Dir_Clie", Dir_Clie));
                objComando.Parameters.Add(new SqlParameter("@Tel_Clie", Tel_Clie));
                objComando.Parameters.Add(new SqlParameter("@Correo_Clie", Correo_Elect));



                objComando.CommandText = "Modificar_Clientes";

                //abrir conexion 
                Conexion.Open();

                objComando.ExecuteNonQuery();

                Conexion.Close();

                return "OK";

            }

            
        }

        public DataTable BuscarClientesDal(string identificacion)
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            //Creamos un objeto de tipo dataset o datatable
            DataTable dtClientes = new DataTable();

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@identificaion", identificacion));
            objComando.CommandText = "BuscarClientesPorIdentica";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtClientes);
            //cerramos la Conexion
            Conexion.Close();

            return dtClientes;
        }

        public DataTable getClientesDal()
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            //Creamos un objeto de tipo dataset o datatable
            DataTable dtClientes = new DataTable();

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getAllClientesYVehiculos";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtClientes);
            //cerramos la Conexion
            Conexion.Close();

            return dtClientes;

        }

        public string Eliminar_Clientes(string identificacion)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@identificacion", identificacion));
            objComando.CommandText = "EliminarCliente";
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";

        }

        public DataTable ValidarTelefono(string Tel_Clie)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            // un objeto de tipo comando que nos va indicar que tipo de consulta va a 
            DataTable dtValidacionT = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            objComando.Parameters.Add(new SqlParameter("@Telefono", Tel_Clie));
            objComando.CommandText = "ValidacionTel";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtValidacionT);
            //cerramos la Conexion
            Conexion.Close();

            return dtValidacionT;
        }

        public DataTable ValidarIden(string identificacion)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            // un objeto de tipo comando que nos va indicar que tipo de consulta va a 
            DataTable dtValidacionId = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            objComando.Parameters.Add(new SqlParameter("@Identificacion", identificacion));
            objComando.CommandText = "NoExistaIdent";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtValidacionId);
            //cerramos la Conexion
            Conexion.Close();

            return dtValidacionId;
        }
    }

}


