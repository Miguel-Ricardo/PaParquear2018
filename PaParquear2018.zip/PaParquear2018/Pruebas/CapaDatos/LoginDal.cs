﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace CapaDatos 
{
    public class LoginDal
    {
        public DataTable ValidarUsuarios(string Correo_Elect, string Contraseña)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtloguin = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Correo", Correo_Elect));
            objComando.Parameters.Add(new SqlParameter("@Contraseña", Contraseña));
            objComando.CommandText = "Loguin";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtloguin);
            //cerramos la Conexion
            Conexion.Close();


            return dtloguin;
        }

        public DataTable ValidarEspacios()
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            DataTable dtloguin = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "EspaciosOcupados";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtloguin);
            //cerramos la Conexion
            Conexion.Close();


            return dtloguin;
        }
    }
    
}
