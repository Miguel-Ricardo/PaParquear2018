﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace CapaDatos 
{
    public class Prueba
    {
        public string InsertarIngresoVehiculoDal(int id_Vehi, int Espacio)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@id_Vehi", id_Vehi));
            objComando.Parameters.Add(new SqlParameter("@Espacio", Espacio));
            objComando.CommandText = "Insertar_Ingreso_Vehi";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }

        public string InsertarREservaVehiculoDal(int id_Vehi, int Espacio)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@id_Vehi", id_Vehi));
            objComando.Parameters.Add(new SqlParameter("@Espacio", Espacio));
            objComando.CommandText = "Insertar_Reserva_Vehi";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }

        public DataTable getMatriculasDal()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "ListarMatriculas";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getMatriculaPAraLAbel(int Id_vehi)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Id_Vehiculo", Id_vehi));
            objComando.CommandText = "ListarMatriculaParaLabel";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getIdIngresoDal(int Matricula)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Matricula", Matricula));
            objComando.CommandText = "ListarIdIngreso";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public string UpdateSalidaParqueadero(int IdVehi)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@id_Matricula", IdVehi));
            objComando.CommandText = "UpdateIngresoVehiculos";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }
    }
}
