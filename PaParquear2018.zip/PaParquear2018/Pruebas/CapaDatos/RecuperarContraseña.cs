﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace CapaDatos 
{
    public class RecuperarContraseña
    {
        public DataTable ValidarIdentificacion(string identificacion)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            // un objeto de tipo comando que nos va indicar que tipo de consulta va a 
            DataTable dtValidacionI = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            objComando.Parameters.Add(new SqlParameter("@Identificacion", identificacion));
            objComando.CommandText = "ValidarInd";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtValidacionI);
            //cerramos la Conexion
            Conexion.Close();

            return dtValidacionI;
        }

        public DataTable ValidarTelefono(string Tel_Usuario)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            // un objeto de tipo comando que nos va indicar que tipo de consulta va a 
            DataTable dtValidacionT = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            objComando.Parameters.Add(new SqlParameter("@Telefono", Tel_Usuario));
            objComando.CommandText = "ValidacionTel";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtValidacionT);
            //cerramos la Conexion
            Conexion.Close();

            return dtValidacionT;
        }

        public DataTable ValidarNombre(string Nom_Usuario)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            // un objeto de tipo comando que nos va indicar que tipo de consulta va a 
            DataTable dtValidacionNom = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            objComando.Parameters.Add(new SqlParameter("@nombre", Nom_Usuario));
            objComando.CommandText = "ValidacionNombre";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtValidacionNom);
            //cerramos la Conexion
            Conexion.Close();

            return dtValidacionNom;
        }

        public DataTable ValidarApelli(string Apelli_Usuario)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            // un objeto de tipo comando que nos va indicar que tipo de consulta va a 
            DataTable dtValidacionApell = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            objComando.Parameters.Add(new SqlParameter("@Apellido", Apelli_Usuario));
            objComando.CommandText = "ValidacionApellido";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtValidacionApell);
            //cerramos la Conexion
            Conexion.Close();

            return dtValidacionApell;
        }
        public DataTable ValidarDir(string Dir_Usuario)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            // un objeto de tipo comando que nos va indicar que tipo de consulta va a 
            DataTable dtValidacionDir = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            objComando.Parameters.Add(new SqlParameter("@Direccion", Dir_Usuario));
            objComando.CommandText = "ValidacionDirecion";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtValidacionDir);
            //cerramos la Conexion
            Conexion.Close();

            return dtValidacionDir;
        }

        public DataTable ValidarCorreo(string Correo_Electronico)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            // un objeto de tipo comando que nos va indicar que tipo de consulta va a 
            DataTable dtValidacionCorreo = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            objComando.Parameters.Add(new SqlParameter("@correo", Correo_Electronico));
            objComando.CommandText = "ValidacionCorreo";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtValidacionCorreo);
            //cerramos la Conexion
            Conexion.Close();

            return dtValidacionCorreo;
        }

        public string ActualizarContraseñaDal(int Identificacion, string ContraseñaNueva, string PreguntaSeg, string RespuestaSeg)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Identificacion", Identificacion));
            objComando.Parameters.Add(new SqlParameter("@ContraseñaNueva", ContraseñaNueva));
            objComando.Parameters.Add(new SqlParameter("@PreguntaSeg", PreguntaSeg));
            objComando.Parameters.Add(new SqlParameter("@RespuestaSeg", RespuestaSeg));
            objComando.CommandText = "RecuperarContraseña";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }

    }
}
