﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace CapaDatos 
{
    public class SupervisorDal
    {
        public DataTable getRestriccionesDal()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getRestricciones";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getUsuariosFormulario()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getUsuariosPorAceptar";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getVehiculosRestriccionDal()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getVehiculosConPPar";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getAllSancionesDal()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getAllSanciones";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }
        public DataTable getSancionUsuarios(int id_placa)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Vehiculo", id_placa));
            objComando.CommandText = "getSancionUsuario";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getSanciones()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getSanciones";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getResrticciones()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getResrticciones";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getSancionesByIdentificacion(int Identificacion)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Identificacion", Identificacion));
            objComando.CommandText = "getSancionesByIdentificacion";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getSancionesByMatriculaDal(int Matricula)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Matricula", Matricula));
            objComando.CommandText = "getSancionesByMatricula";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public string InsertSancionesDal(string Nombre_sancion, DateTime Fecha_inicio, int id_Vehi, int Estado)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@NombreSancion", Nombre_sancion));
            objComando.Parameters.Add(new SqlParameter("@fechaInicio", Fecha_inicio));
            objComando.Parameters.Add(new SqlParameter("@id_vehi", id_Vehi));
            objComando.Parameters.Add(new SqlParameter("@Estado", Estado));
            objComando.CommandText = "Insertar_Sancion";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }

        public string DeleteSanciones(int id_sanciones)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@id_sancion", id_sanciones));
            objComando.CommandText = "EliminarSancion";
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";

        }

        public string DeleteUsuariosF(int identificacion)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@identificacion", identificacion));
            objComando.CommandText = "NoAceptarUSuarioF";
            Conexion.Open(); 

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";

        }

        public string UpdateSanciones(string Nombre_sancion, DateTime Fecha_inicio, DateTime Fecha_final, int identificacion)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Nombre_sancion", Nombre_sancion));
            objComando.Parameters.Add(new SqlParameter("@fecha_inicio", Fecha_inicio));
            objComando.Parameters.Add(new SqlParameter("@fecha_final", Fecha_final));
            objComando.Parameters.Add(new SqlParameter("@identificacion", identificacion));
            objComando.CommandText = "UpdateSanciones";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }

        public string AgregarUsuariosF(int identificacion)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@identificacion", identificacion));
            objComando.CommandText = "AñadirUsuariosF";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }

        public string UpdateEstadoDal (int estado)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Estado", estado));
            objComando.CommandText = "UpdateRestricciones";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }
    }
}
