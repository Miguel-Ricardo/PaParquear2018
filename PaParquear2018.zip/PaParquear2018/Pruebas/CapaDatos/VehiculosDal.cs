﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace CapaDatos 
{
    public class VehiculosDal
    {
        public string Insertar_VehiDal(string Matricula_Vehi, string Modelo_Vehi, string Color_Vehi, string identifica_fk)
        {
            //crear un objeto de tipo conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            //objComando.Parameters.Add(new SqlParameter("@id_Usuario", Id));
            objComando.Parameters.Add(new SqlParameter("@Matricula_Vehi", Matricula_Vehi));
            objComando.Parameters.Add(new SqlParameter("@Modelo_Vehi", Modelo_Vehi));
            objComando.Parameters.Add(new SqlParameter("@Color_Vehi", Color_Vehi));
            objComando.Parameters.Add(new SqlParameter("@identifica_fk", identifica_fk));
            objComando.CommandText = "Insertar_Vehiculos";

            //abrir conexion 
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";
        }

        public string Modificar_VehiculoDal( string Matricula_Vehi, string Modelo_Vehi, string Color_Vehi, string identifica_fk)
        {

            {
                //crear un objeto de tipo conexion
                SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

                // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
                IDbCommand objComando = Conexion.CreateCommand();
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.Add(new SqlParameter("@Matricula_Vehi", Matricula_Vehi));
                objComando.Parameters.Add(new SqlParameter("@Modelo_Vehi", Modelo_Vehi));
                objComando.Parameters.Add(new SqlParameter("@Color_Vehi", Color_Vehi));
                objComando.Parameters.Add(new SqlParameter("@identifica_fk", identifica_fk));


                objComando.CommandText = "Modificar_Vehiculos";

                //abrir conexion 
                Conexion.Open();

                objComando.ExecuteNonQuery();

                Conexion.Close();

                return "OK";
            }

        }
        public string Eliminar_Vehiculos(string identifica_fk)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            // un objeto de tipo comando que nos va indicar que tipo de consulta va a ejecutar
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@identifica_fk", identifica_fk));
            objComando.CommandText = "EliminarVehiculo";
            Conexion.Open();

            objComando.ExecuteNonQuery();

            Conexion.Close();

            return "OK";

        }

    }    
}
