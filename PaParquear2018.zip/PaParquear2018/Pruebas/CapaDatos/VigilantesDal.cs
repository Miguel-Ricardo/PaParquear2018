﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace CapaDatos 
{
    public class VigilantesDal
    {
        public DataTable getVigilantesDal()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getVigilantes";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getEstadoRestriccionDal()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getEstadoRestriccion";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getCantidadesDal()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getAdmiAllIngresos";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getIdIngresoDal()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getIdIngresos";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getMatriculaDal()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getMatricula";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }


        public DataTable getCantidadesByMatriculaDal(string Id)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Matricula", Id));
            objComando.CommandText = "getAdmilIngresosByMatricula";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getIngresoVehiculosDal()
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.CommandText = "getAllIngresoVehiculos";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        /// <summary>
        /// Metodo que consulta un mecanico en especifico
        /// </summary>
        /// <param name="Nit">Identificacion del mecanico a buscar</param>
        /// <returns>DataTable con la informacion del mecanico</returns>
        public DataTable getIngresoVehiculosByIdDal(string Id)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Matricula_Vehi", Id));
            objComando.CommandText = "getIngresoVehiculosById";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getSancionesClientes (string Matricula)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Matricula_Vehiculo", Matricula));
            objComando.CommandText = "getSancionesClientes";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getCantidadesByMAtriculaDal(int Id)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@id_Vehi", Id));
            objComando.CommandText = "getAdmilIngresosByMatricula";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getVigilantesContraseña(string Nit)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Nit", Nit));
            objComando.CommandText = "getVigilanteContraseña";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable ValidarVehiculoDal(int id_vehi)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@id_Vehi", id_vehi));
            objComando.CommandText = "validarVehiculo";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getIngresosPorFechaDal(DateTime PrimeraFecha, DateTime SegundaFecha)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@PrimeraFecha", PrimeraFecha));
            objComando.Parameters.Add(new SqlParameter("@SegundaFecha", SegundaFecha));
            objComando.CommandText = "getIngresosPorFechas";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getIngresosPorFechaSalidaDal(DateTime PrimeraFecha, DateTime SegundaFecha)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@PrimeraFecha", PrimeraFecha));
            objComando.Parameters.Add(new SqlParameter("@SegundaFecha", SegundaFecha));
            objComando.CommandText = "getIngresoPorFechaSalida";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public DataTable getIngresosFechas(DateTime PrimeraFecha, DateTime SegundaFecha)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo DataSet o DataTable
            DataTable dtVigilantes = new DataTable();

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@PrimeraFecha", PrimeraFecha));
            objComando.Parameters.Add(new SqlParameter("@SegundaFecha", SegundaFecha));
            objComando.CommandText = "getIngresosFechas";

            //Crear un objeto de tipo adaptador (llrna el DataTable)
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);

            //Abrir la conexion
            Conexion.Open();
            //Llenar el adaptador
            Adaptador.Fill(dtVigilantes);
            //Cerrar conexion
            Conexion.Close();

            return dtVigilantes;
        }

        public string InsertIngresoVehiculosDal (DateTime Fecha_Ingreso, DateTime Fecha_Salida, int id_Vehi, int id_Clie)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@Fecha_Ingreso", Fecha_Ingreso));
            objComando.Parameters.Add(new SqlParameter("@Fecha_Salida", Fecha_Salida));
            objComando.Parameters.Add(new SqlParameter("@id_Vehi", id_Vehi));
            objComando.Parameters.Add(new SqlParameter("@Id_Usuario", id_Clie));
            objComando.CommandText = "Insertar_Ingreso_Vehi";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }

        public string UpdateContraseñaVigilante(string ContraseñaVieja, string ContraseñaNueva)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@ContraseñaVieja", ContraseñaVieja));
            objComando.Parameters.Add(new SqlParameter("@ContraseñaNueva", ContraseñaNueva));
            objComando.CommandText = "UpdateContraseñaVigilante";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }

        public string UpdateIngresoVehiculosDal(int id_Vehi)
        {
            //Crear un objeto conexion
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);

            //Crear un objeto de tipo comando
            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;
            objComando.Parameters.Add(new SqlParameter("@id_Matricula", id_Vehi));
            objComando.CommandText = "UpdateIngresoVehiculos";

            //Abrir conexion
            Conexion.Open();

            //Ejecutamos el procedimiento almacenado (se usa solo cuando se va a crear y no se retornara nada)
            objComando.ExecuteNonQuery();

            //Cerrar conexion
            Conexion.Close();

            return "Ok";
        }

        public DataTable ValidarVigilante(string Correo_Elect, string Contraseña)
        {
            SqlConnection Conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionPaParquear"].ConnectionString);
            // un objeto de tipo comando que nos va indicar que tipo de consulta va a 
            DataTable dtValidacionVigil = new DataTable();

            IDbCommand objComando = Conexion.CreateCommand();
            objComando.CommandType = CommandType.StoredProcedure;

            objComando.Parameters.Add(new SqlParameter("@Correo_Elect", Correo_Elect));
            objComando.Parameters.Add(new SqlParameter("@Contraseña", Contraseña));
            objComando.CommandText = "ValidarVigilante";

            //crear un objeto de tipo adaptador  llenamos el datatable
            SqlDataAdapter Adaptador = new SqlDataAdapter((SqlCommand)objComando);
            //abrir la conexion
            Conexion.Open();
            //llenar el datatable con el adaptador
            Adaptador.Fill(dtValidacionVigil);
            //cerramos la Conexion
            Conexion.Close();

            return dtValidacionVigil;
        }
    }
}
