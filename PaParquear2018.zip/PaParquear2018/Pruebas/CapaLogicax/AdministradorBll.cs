﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CapaDatos;

namespace CapaLogica
{
   public class AdministradorBll
    {
        public DataTable getUsuariosBll(int identificacion)
        {
            //creamos el datatable que va a recibir la informacion de mecanicosdal
            DataTable dtUsauarios = new DataTable();

            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            //llamanos al procedimiento getMecanicosDal y almacenamos en el data table el listado de mecanicos
            dtUsauarios = objUsuariosDal.getUsuariosDal(identificacion);

            //retornamos el datatable a la vista 
            return dtUsauarios;

        }
        public DataTable getClientesBll(int identificacion)
        {
            //creamos el datatable que va a recibir la informacion de mecanicosdal
            DataTable dtUsauarios = new DataTable();

            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            //llamanos al procedimiento getMecanicosDal y almacenamos en el data table el listado de mecanicos
            dtUsauarios = objUsuariosDal.getClientesDal(identificacion);

            //retornamos el datatable a la vista 
            return dtUsauarios;

        }
        public DataTable getTodosLosUsuariosBll(int identificacion)
        {
            //creamos el datatable que va a recibir la informacion de mecanicosdal
            DataTable dtUsauarios = new DataTable();

            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            //llamanos al procedimiento getMecanicosDal y almacenamos en el data table el listado de mecanicos
            dtUsauarios = objUsuariosDal.getTodosLosUsuariosDal(identificacion);

            //retornamos el datatable a la vista 
            return dtUsauarios;

        }

        public DataTable MostrarTodosUsuariosBll()
        {
            //creamos el datatable que va a recibir la informacion de mecanicosdal
            DataTable dtUsauarios = new DataTable();

            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            //llamanos al procedimiento getMecanicosDal y almacenamos en el data table el listado de mecanicos
            dtUsauarios = objUsuariosDal.MostrarTodosUsuariosDal();

            //retornamos el datatable a la vista 
            return dtUsauarios;

        }

        public String insertar_VigilantesBll(string identificacion, string Nom_Usuario, string Apelli_Usuario, string Dir_Usuario,
            string Tel_Usuario, int id_rol, string Contraseña, string Correo_Elect, int Turno, string PreguntaSeg, string RespuestaSeg,
            int Estado)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objUsuariosDal.Insertar_VigilantesDal(identificacion, Nom_Usuario, Apelli_Usuario, Dir_Usuario,
            Tel_Usuario, id_rol, Contraseña, Correo_Elect,Turno, PreguntaSeg, RespuestaSeg, Estado);

            //retornar el valor del resultado
            return Resultado;

        }

        public String insertar_AdminSupervisorBll(string identificacion, string Nom_Usuario, string Apelli_Usuario, string Dir_Usuario,
            string Tel_Usuario, int id_rol, string Contraseña, string Correo_Elect, string PreguntaSeg, string RespuestaSeg,
            int Estado)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objUsuariosDal.Insertar_AdminSupervisorDal(identificacion, Nom_Usuario, Apelli_Usuario, Dir_Usuario,
            Tel_Usuario, id_rol, Contraseña, Correo_Elect, PreguntaSeg, RespuestaSeg, Estado);

            //retornar el valor del resultado
            return Resultado;

        }

        public String AutoRegistroBll(string identificacion, string Nom_Usuario, string Apelli_Usuario, string Dir_Usuario,
            string Tel_Usuario, int id_rol, string Contraseña, string Correo_Elect, string PreguntaSeg, string RespuestaSeg,
            int Estado, string Matricula, string Modelo, string Color)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objUsuariosDal.AutoRegistro(identificacion, Nom_Usuario, Apelli_Usuario, Dir_Usuario,
            Tel_Usuario, id_rol, Contraseña, Correo_Elect, PreguntaSeg, RespuestaSeg, Estado, Matricula, Modelo, Color);

            //retornar el valor del resultado
            return Resultado;

        }

        public DataTable BuscarPorIdentificacionBll(string identificacion)
        {
            //creamos el datatable que va a recibir la informacion de mecanicosdal
            DataTable dtUsuarios = new DataTable();

            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            //llamanos al procedimiento getMecanicosDal y almacenamos en el data table el listado de mecanicos
            dtUsuarios = objUsuariosDal.BuscarPorIdentificaionDal(identificacion);

            //retornamos el datatable a la vista 
            return dtUsuarios;
        }

        public String Modificar_UsuariosBll(string Identificacion, string Dir_Usuario,
            string Tel_Usuario, string Contraseña, string Correo_Elect,string PreguntaSeg, string RespuestaSeg,string Matricula, 
            string Modelo, string Color)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objUsuariosDal.Modificar_UsuariosDal(Identificacion, Dir_Usuario,
            Tel_Usuario, Contraseña, Correo_Elect, PreguntaSeg, RespuestaSeg, Matricula, Modelo, Color); 

            //retornar el valor del resultado
            return Resultado;
        }

        public String Modificar_VigilantesBll(string Identificacion, string Dir_Usuario,
            string Tel_Usuario, string Contraseña, string Correo_Elect, int Turno, string PreguntaSeg, string RespuestaSeg)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objUsuariosDal.Modificar_VigilantesDal(Identificacion, Dir_Usuario,
            Tel_Usuario, Contraseña, Correo_Elect, Turno, PreguntaSeg, RespuestaSeg);

            //retornar el valor del resultado
            return Resultado;
        }

        public String Modificar_SupervisoresBll(string Identificacion, string Dir_Usuario,
            string Tel_Usuario, string Contraseña, string Correo_Elect, string PreguntaSeg, string RespuestaSeg)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objUsuariosDal.Modificar_SupervisoresDal(Identificacion, Dir_Usuario,
            Tel_Usuario, Contraseña, Correo_Elect, PreguntaSeg, RespuestaSeg);

            //retornar el valor del resultado
            return Resultado;
        }

        public String Eliminar_Usuarios(int id_Usuarios)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            AdministradorDal objUsuariosDal = new AdministradorDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objUsuariosDal.Eliminar_Usuarios(id_Usuarios);

            //retornar el valor del resultado
            return Resultado;

        }
        public DataTable llenarUsuariosBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.llenarUsuarios();

            return dtUsuarios;
        }
        public DataTable getAllRestriccionesBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.getAllRestriccionesDal();

            return dtUsuarios;
        }
        public DataTable getRestriccionesActivasBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.getRestriccionesActivasDal();

            return dtUsuarios;
        }

        public DataTable ConsultaRapidaIngresosBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.ConsultaRapidaIngresosDal();

            return dtUsuarios;
        }
        public DataTable ConsultaRapidaIngresosMesBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.ConsultaRapidaIngresosMesDal();

            return dtUsuarios;
        }
        public DataTable ConsultaRapidaIngresosHoyBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.ConsultaRapidaIngresosHoyDal();

            return dtUsuarios;
        }

        public DataTable ValidarIdentificacion(string identificacion)
        {
            DataTable dtValidacionI = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtValidacionI = objUsuariosDal.ValidarIdentificacion(identificacion);

            return dtValidacionI;

        }

        public DataTable ValidarTelefono(string Tel_Clie)
        {
            DataTable dtValidacionT = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtValidacionT = objUsuariosDal.ValidarTelefono(Tel_Clie);

            return dtValidacionT;

        }

        public DataTable getIngresoByMatriculaBll(int Placa)
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.getIngresoByMatriculaDal(Placa);

            return dtUsuarios;

        }

        public DataTable ConsultaRapidaSupervisoresBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.ConsultaRapidaSupervisoresDal();

            return dtUsuarios;
        }
        public DataTable ConsultaRapidaVigilantesBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.ConsultaRapidaVigilantesDal();

            return dtUsuarios;
        }
        public DataTable ConsultaRapidaClientesBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.ConsultaRapidaClientesDal();

            return dtUsuarios;
        }

        public DataTable getAllIngresosBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.getAllIngresosDal();

            return dtUsuarios;
        }

        public DataTable ConsultaRapidaRestriccionesBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.ConsultaRapidaRestriccionesDal();

            return dtUsuarios;
        }
        public DataTable ConsultaRapidaSancionesBll()
        {
            DataTable dtUsuarios = new DataTable();

            AdministradorDal objUsuariosDal = new AdministradorDal();

            dtUsuarios = objUsuariosDal.ConsultaRapidaSancionesDal();

            return dtUsuarios;
        }
    }
}
