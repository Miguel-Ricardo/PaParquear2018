﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using System.Data;
using System.Data.SqlClient;

namespace CapaLogica
{
    public class ClientesBll
    {

        public string ObtenerClientesBll(string Nombres, string Apellidos, string NumeroDocumento, string Direccion, string Telefono)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            ClientesDall objClientesBll = new ClientesDall();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objClientesBll.ObtenerClientesDal(Nombres, Apellidos, NumeroDocumento, Direccion, Telefono);
            return Retorno;

        }
        public string Insertar_ClientesDal(string identificacion, string Nom_Clie, string Apelli_Clie, string Dir_Clie,
            string Tel_Clie, string Correo_Elect)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            ClientesDall objClientesDal = new ClientesDall();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objClientesDal.Insertar_ClientesDal(identificacion, Nom_Clie, Apelli_Clie, Dir_Clie,
            Tel_Clie, Correo_Elect);

            //retornar el valor del resultado
            return Resultado;

        }

        public String Modificar_ClientesBll (string identificacion, string Nom_Clie, string Apelli_Clie, string Dir_Clie,
            string Tel_Clie, string Correo_Elect)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            ClientesDall objClientesDal = new ClientesDall();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objClientesDal.Modificar_ClienesDal(identificacion, Nom_Clie, Apelli_Clie, Dir_Clie,
            Tel_Clie, Correo_Elect); ;

            //retornar el valor del resultado
            return Resultado;
        }


        public DataTable BuscarClientesBll(string identificacion)
        {
            //creamos el datatable que va a recibir la informacion de mecanicosdal
            DataTable dtClientes = new DataTable();

            //creamos e instanciamos un objetpo de la clase mecanicosDal
            ClientesDall objClientesDal = new ClientesDall();

            //llamanos al procedimiento getMecanicosDal y almacenamos en el data table el listado de mecanicos
            dtClientes = objClientesDal.BuscarClientesDal(identificacion);

            //retornamos el datatable a la vista 
            return dtClientes;
        }

        public DataTable getClientesBll()
        {
            //creamos el datatable que va a recibir la informacion de mecanicosdal
            DataTable dtClientesBll = new DataTable();

            //creamos e instanciamos un objetpo de la clase mecanicosDal
            ClientesDall objClientesDal = new ClientesDall();

            //llamanos al procedimiento getMecanicosDal y almacenamos en el data table el listado de mecanicos
            dtClientesBll = objClientesDal.getClientesDal();

            //retornamos el datatable a la vista 
            return dtClientesBll;

        }

        public String Eliminar_Clientes(string identificacion)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            ClientesDall objClientesDal = new ClientesDall();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objClientesDal.Eliminar_Clientes(identificacion);

            //retornar el valor del resultado
            return Resultado;

        }
        public DataTable ValidarTelefono(string Tel_Clie)
        {
            DataTable dtValidacionT = new DataTable();

            ClientesDall objClientesDal = new ClientesDall();

            dtValidacionT = objClientesDal.ValidarTelefono(Tel_Clie);

            return dtValidacionT;

        }


        public DataTable ValidarIden(string identificacion)
        {
            DataTable dtValidacionId = new DataTable();

            ClientesDall objClientesDal = new ClientesDall();

            dtValidacionId = objClientesDal.ValidarIden(identificacion);

            return dtValidacionId;

        }





    }
}

