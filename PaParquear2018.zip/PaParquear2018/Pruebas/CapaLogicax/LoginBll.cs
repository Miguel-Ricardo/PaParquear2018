﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using CapaDatos;

namespace CapaLogica
{
    public class LoginBll
    {
        public DataTable VerificarUsuario(string Usuario, string Contraseña)
        {
            DataTable dtLoguin = new DataTable();

            LoginDal objloguinDal = new LoginDal();

            dtLoguin = objloguinDal.ValidarUsuarios(Usuario, Contraseña);

            return dtLoguin;
        }

        public DataTable verificarEspacios()
        {
            DataTable dtLoguin = new DataTable();

            LoginDal objloguinDal = new LoginDal();

            dtLoguin = objloguinDal.ValidarEspacios();

            return dtLoguin;
        }
    }
}
