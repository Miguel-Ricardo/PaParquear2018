﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CapaDatos;

namespace CapaLogica
{
    public class ModificarContraBll
    {
        public String Modificar_ContraBll(int identificacion, string Contraseña)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            CambiarContraseñaDal objCambiarContraDal = new CambiarContraseñaDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objCambiarContraDal.UpdateContraseñaDal(identificacion, Contraseña); ;

            //retornar el valor del resultado
            return Resultado;
        }
    }
}
