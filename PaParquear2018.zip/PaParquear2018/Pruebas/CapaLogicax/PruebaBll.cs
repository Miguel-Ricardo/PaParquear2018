﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;

namespace CapaLogica
{
    public class PruebaBll
    {
        public string InsertarIngresoVehiculoBll(int id_Vehi, int Espacio)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            Prueba objMecanicosBll = new Prueba();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.InsertarIngresoVehiculoDal(id_Vehi, Espacio);
            return Retorno;

        }

        public string InsertarResesrvaVehiculoBll(int id_Vehi, int Espacio)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            Prueba objMecanicosBll = new Prueba();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.InsertarREservaVehiculoDal(id_Vehi, Espacio);
            return Retorno;

        }

        public DataTable getMAtriculas()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            Prueba oVigilantesBll = new Prueba();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getMatriculasDal();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getIdIngresoBll(int Matricula)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            Prueba oVigilantesBll = new Prueba();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getIdIngresoDal(Matricula);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getMatriculaParaLabelBll(int Id_Vehi)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            Prueba oVigilantesBll = new Prueba();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getMatriculaPAraLAbel(Id_Vehi);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public string UpdateSalidaParqueaderoBll(int IdVehi)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            Prueba objMecanicosBll = new Prueba();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.UpdateSalidaParqueadero(IdVehi);
            return Retorno;
        }
    }
}
