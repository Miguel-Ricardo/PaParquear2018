﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CapaDatos;

namespace CapaLogica
{
    public class RecuperarContraseñaBll
    {
        public DataTable ValidarIdentificacion(string identificacion)
        {
            DataTable dtValidacionI = new DataTable();

            RecuperarContraseña objRecuperarDal = new RecuperarContraseña();
            

            dtValidacionI = objRecuperarDal.ValidarIdentificacion(identificacion);

            return dtValidacionI;

        }

        public string ActualizarContraseñaBll(int Identificacion, string ContraseñaNueva, string PreguntaSeg, string RespuestaSeg)
        {
            RecuperarContraseña objMecanicosBll = new RecuperarContraseña();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.ActualizarContraseñaDal(Identificacion, ContraseñaNueva, PreguntaSeg, RespuestaSeg);
            return Retorno;

        }

        public DataTable ValidarTelefono(string Tel_Usuario)
        {
            DataTable dtValidacionT = new DataTable();

            RecuperarContraseña objRecuperarDal = new RecuperarContraseña();

            dtValidacionT = objRecuperarDal.ValidarTelefono(Tel_Usuario);

            return dtValidacionT;

        }
        public DataTable ValidarNombre(string Nom_Usuario)
        {
     
            DataTable dtValidacionNom = new DataTable();

            RecuperarContraseña objRecuperarDal = new RecuperarContraseña();

            dtValidacionNom = objRecuperarDal.ValidarNombre(Nom_Usuario);

            return dtValidacionNom;

        }
        public DataTable ValidarCorreo(string Correo_Electronico)
        {

            DataTable dtValidacionCorreo = new DataTable();

            RecuperarContraseña objRecuperarDal = new RecuperarContraseña();

            dtValidacionCorreo = objRecuperarDal.ValidarCorreo(Correo_Electronico);

            return dtValidacionCorreo;

        }
        public DataTable ValidarApelli(string Apelli_Usuario)
        {

            DataTable dtValidacionApelli = new DataTable();

            RecuperarContraseña objRecuperarDal = new RecuperarContraseña();

            dtValidacionApelli = objRecuperarDal.ValidarApelli(Apelli_Usuario);

            return dtValidacionApelli;

        }
        public DataTable ValidarDir(string Dir_Usuario)
        {

            DataTable dtValidacionDirecci = new DataTable();

            RecuperarContraseña objRecuperarDal = new RecuperarContraseña();

            dtValidacionDirecci = objRecuperarDal.ValidarDir(Dir_Usuario);

            return dtValidacionDirecci;

        }

        public string UpdateContraseñaBll(int Identificacion, string Contraseña)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            CambiarContraseñaDal objMecanicosBll = new CambiarContraseñaDal();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.UpdateContraseñaDal(Identificacion, Contraseña);
            return Retorno;
        }
    }
}
