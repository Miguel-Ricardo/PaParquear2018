﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using CapaDatos;

namespace CapaLogica
{
    public class SupervisorBll
    {
        public DataTable getRestriccionesBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal oVigilantesBll = new SupervisorDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getRestriccionesDal();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getVehiculosRestriccionBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal oVigilantesBll = new SupervisorDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getVehiculosRestriccionDal();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getAllSancionesBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal oVigilantesBll = new SupervisorDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getAllSancionesDal();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }
        public DataTable getSancionUsuariosBll(int id_placa)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal 
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal oVigilantesBll = new SupervisorDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getSancionUsuarios(id_placa);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getUsuariosFBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal oVigilantesBll = new SupervisorDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getUsuariosFormulario();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getSancionesBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal oVigilantesBll = new SupervisorDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getSanciones();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getResrticcionesDDLBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal oVigilantesBll = new SupervisorDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getResrticciones();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getSancionesByIdentificacionBll(int Identificacion)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal oVigilantesBll = new SupervisorDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getSancionesByIdentificacion(Identificacion);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getSancionesByMatriculaBll(int Matricula)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal oVigilantesBll = new SupervisorDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getSancionesByMatriculaDal(Matricula);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public string InsertSancionesBll(string Nombre_sancion, DateTime Fecha_inicio,int id_Vehi, int Estado)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal objMecanicosBll = new SupervisorDal();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.InsertSancionesDal(Nombre_sancion, Fecha_inicio,id_Vehi, Estado);
            return Retorno;

        }

        public String DeleteSancionesBll(int id_sancion)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            SupervisorDal objUsuariosDal = new SupervisorDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objUsuariosDal.DeleteSanciones(id_sancion);

            //retornar el valor del resultado
            return Resultado;

        }

        public String DeleteUsuariosFBll(int identificacion)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            SupervisorDal objUsuariosDal = new SupervisorDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objUsuariosDal.DeleteUsuariosF(identificacion);

            //retornar el valor del resultado
            return Resultado;

        }

        public string UpdateSancionesBll(string Nombre_sancion, DateTime Fecha_inicio, DateTime Fecha_final, int identificacion)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal objMecanicosBll = new SupervisorDal();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.UpdateSanciones(Nombre_sancion, Fecha_inicio, Fecha_final, identificacion);
            return Retorno;
        }

        public string UpdateEstadoBll (int estado)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal objMecanicosBll = new SupervisorDal();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.UpdateEstadoDal(estado);
            return Retorno;
        }

        public string AgregarUsuarioFBll(int identificacion)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            SupervisorDal objMecanicosBll = new SupervisorDal();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.AgregarUsuariosF(identificacion);
            return Retorno;
        }
    }
}
