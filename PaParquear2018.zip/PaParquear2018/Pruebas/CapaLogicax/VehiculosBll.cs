﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using System.Data;
using System.Data.SqlClient;

namespace CapaLogica
{
     public class VehiculosBll
    {
        public string Insertar_VehiDal(string Matricula_Vehi, string Modelo_Vehi, string Color_Vehi, string identifica_fk)
        {
            
            VehiculosDal objVehiculosDal = new VehiculosDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objVehiculosDal.Insertar_VehiDal(Matricula_Vehi, Modelo_Vehi, Color_Vehi, identifica_fk);


            //retornar el valor del resultado
            return Resultado;

        }

        public String Modificar_VehiculosBll ( string Matricula_Vehi, string Modelo_Vehi, string Color_Vehi, string identifica_fk)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            VehiculosDal objVehiculosDal = new VehiculosDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objVehiculosDal.Modificar_VehiculoDal( Matricula_Vehi, Modelo_Vehi, Color_Vehi, identifica_fk);

            //retornar el valor del resultado
            return Resultado;
        }

        public String Eliminar_Vehiculos(string identifica_fk)
        {
            //creamos e instanciamos un objetpo de la clase mecanicosDal
            VehiculosDal objVehiculosDal = new VehiculosDal();

            string Resultado;

            //invoco el metodo insertMecanicoDal
            Resultado = objVehiculosDal.Eliminar_Vehiculos(identifica_fk);

            //retornar el valor del resultado
            return Resultado;

        }
    }
}
