﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using CapaDatos;

namespace CapaLogica
{
    public class VigilanteBll
    {
        public DataTable getVigilantesBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getVigilantesDal();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getEstadoRestriccionBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getEstadoRestriccionDal();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getCantidadesBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getCantidadesDal();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getIdIngresoBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getIdIngresoDal();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getMatriculaBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getMatriculaDal();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getCantidadesByMatriculaBll(string Id)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getCantidadesByMatriculaDal(Id);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getAllIngresoVehiculosBll()
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getIngresoVehiculosDal();

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        /// <summary>
        /// Metodo que se encarga de obtener la informacion necesaria para un mecanico
        /// </summary>
        /// <param name="Nit">Numero de identificacion del mecanico</param>
        /// <returns>DataTable con la informacion del mecanico</returns>
        public DataTable getIngresoVehiculosByIdBll(string Id)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getIngresoVehiculosByIdDal(Id);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getSancionesClientesBll(string Matricula)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getSancionesClientes(Matricula);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getVigilantesContraseñaBll (string Nit)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getVigilantesContraseña(Nit);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable ValidarVehiculoBll(int id_Vehi)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.ValidarVehiculoDal(id_Vehi);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getIngresosPorFechaBll(DateTime PrimeraFecha, DateTime SegundaFecha)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getIngresosPorFechaDal(PrimeraFecha, SegundaFecha);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getIngresosPorFechaSalidaBll(DateTime PrimeraFecha, DateTime SegundaFecha)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getIngresosPorFechaSalidaDal(PrimeraFecha, SegundaFecha);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public DataTable getIngresosFechas(DateTime PrimeraFecha, DateTime SegundaFecha)
        {
            //Crear el DataTable que recibira la informacion de MecanicosDal
            DataTable dtVigilantes = new DataTable();

            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal oVigilantesBll = new VigilantesDal();

            //Llamamos al procedimiento getMEcanicosDal y almacenamos en el DataTable el listado de mecanicos
            dtVigilantes = oVigilantesBll.getIngresosFechas(PrimeraFecha, SegundaFecha);

            //retornamos el DataTable a la vista
            return dtVigilantes;
        }

        public string InsertMecanicosBll(DateTime Fecha_Ingreso, DateTime Fecha_Salida, int id_Vehi, int id_Clie)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal objMecanicosBll = new VigilantesDal();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.InsertIngresoVehiculosDal(Fecha_Ingreso, Fecha_Salida, id_Vehi, id_Clie);
            return Retorno;

        }

        public string UpdateContraseñaVigilanteBll(string ContraseñaVieja, string ContraseñaNueva)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal objMecanicosBll = new VigilantesDal();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.UpdateContraseñaVigilante(ContraseñaVieja, ContraseñaNueva);
            return Retorno;
        }

        public string UpdateIngresoVehiculosBll(int id_Vehi)
        {
            //Crear e instanciar un objeto de la clase MecanicosDal
            VigilantesDal objMecanicosBll = new VigilantesDal();

            //Variable para almacenar el valor que retorna el metodo InsertMecanicos
            string Retorno;

            //Llamamos al procedimiento InsertMecanicosDal 
            Retorno = objMecanicosBll.UpdateIngresoVehiculosDal(id_Vehi);
            return Retorno;
        }

        public DataTable ValidarVigilante(string Correo_Elect, string Contraseña)
        {
            DataTable dtValidacionVigil = new DataTable();

            VigilantesDal objValidacionVigBll = new VigilantesDal();


            dtValidacionVigil = objValidacionVigBll.ValidarVigilante(Correo_Elect, Contraseña);

            return dtValidacionVigil;

        }
    }
}
