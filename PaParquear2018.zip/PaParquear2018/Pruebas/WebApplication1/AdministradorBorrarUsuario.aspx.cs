﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class AdministradorBorrarUsuario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                if (sesion != 1)
                {
                    Response.Redirect("Index.aspx", false);
                }

            }
            catch
            {
                Response.Redirect("Index.aspx");
            }
            if (!IsPostBack)
            {
                alertError.Attributes.Add("style", "display:none");
                alertSuccess.Attributes.Add("style", "display:none");
            }
        }


        protected void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                AdministradorBll objUsuariosBll = new AdministradorBll();

                //creo variables para almacenar casa uno de los campos de la caja de texto


                // creo una variable que reciba el resultasp del query
                int id_usuario = int.Parse(txtIdentificacion.Text);
                string Resultado;

                //invoco el metodo en Bll insertMecanico
                Resultado = objUsuariosBll.Eliminar_Usuarios(id_usuario);

                if (Resultado == "OK")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "El Usuario se inhabilito correctamente";
                }

            }
            catch (Exception)
            {

                alertError.Attributes.Add("style", "display:blok");
                LblError.Text = "Se presento un error al inhabilitar el Vehiculo. Detalle error : ";

            }
        }

        protected void BtnBuscarUsuarios_Click(object sender, EventArgs e)
        {
            try
            {

                DataTable dtUsuarios = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();
                int identificacion = int.Parse(txtIdentificacion.Text);

                //llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
                dtUsuarios = objUsuariosBll.getTodosLosUsuariosBll(identificacion);

                //seleccionamos el origen de datos para el datagriview
                GvUsuarios.DataSource = dtUsuarios;
                GvUsuarios.DataBind();

            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "se presento un error al listar los registros :" + ex.Message.ToString();
            }
            finally
            {

            }
        }
    }
}