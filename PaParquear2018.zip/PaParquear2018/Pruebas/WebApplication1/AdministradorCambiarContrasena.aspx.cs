﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class AdministradorCambiarContrasena : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        { 
            try
            {
                Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                if (sesion != 1)
                {
                    Response.Redirect("Index.aspx", false);
                }

            }
            catch
            {
                Response.Redirect("Index.aspx");
            }
            if (!IsPostBack)
            {
                alertError.Attributes.Add("style", "display:none");
                alertSuccess.Attributes.Add("style", "display:none");
            }
        }


        protected void BtnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                //Crear e instanciamos un objeto de la clase MecanicosByNitBll
                RecuperarContraseñaBll oVigilantes = new RecuperarContraseñaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                
                int Identificacion = int.Parse(txtIdentificacion.Text);
                string Contraseña = txtContraseña.Text;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo UpdateMecanicos
                Retorno = oVigilantes.UpdateContraseñaBll(Identificacion, Contraseña);

                //Valido si el registro se inserto correctamente
                if (Retorno == "OK")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Contraseña actualizada correctamente";
                }else
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "Error al actualizar la contraseña";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al actualizar la contraseña, probablemente el error este en que la contraseña anterior/actual no es correcta Detaller Error: " + ex.Message.ToString();
            }
        }

        protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
            txtIdentificacion.Text = "";
            lblSuccess.Text = "";
            LblError.Text = "";
            alertError.Attributes.Add("style", "display:none");
            alertSuccess.Attributes.Add("style", "display:none");
        }
    }
}