﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class AdministradorConsultaRapida : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                    if (sesion != 1)
                    {
                        Response.Redirect("Index.aspx", false);
                    }

                }
                catch
                {
                    Response.Redirect("Index.aspx");
                }
                alertError.Attributes.Add("style", "display:none");
                try
                {

                    DataTable dtUsuarios = new DataTable();

                    //creamos e instanciamos un objeto de la clase mecanicosBll
                    AdministradorBll objUsuariosBll = new AdministradorBll();

                    //almacenar en una variable el contenido de la caja de texto con el nit a buscar


                    //llamar la funcion getMecanicoByNItBll
                    dtUsuarios = objUsuariosBll.ConsultaRapidaIngresosBll();

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado

                        lblIngresosTotales.Text = dtUsuarios.Rows[0]["Ingresos_Totales"].ToString();
                    }
                    else
                    {
                        alertError.Attributes.Add("style", "display:none");

                    }

                    //llamar la funcion getMecanicoByNItBll
                    dtUsuarios = objUsuariosBll.ConsultaRapidaIngresosMesBll();

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado

                        lblIngresosMes.Text = dtUsuarios.Rows[0]["Ingresos_Mes"].ToString();
                    }
                    else
                    {
                        alertError.Attributes.Add("style", "display:none");

                    }
                    //llamar la funcion getMecanicoByNItBll
                    dtUsuarios = objUsuariosBll.ConsultaRapidaIngresosHoyBll();

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado

                        lblIngresosHoy.Text = dtUsuarios.Rows[0]["Ingresos_Hoy"].ToString();
                    }
                    else
                    {
                        alertError.Attributes.Add("style", "display:none");

                    }

                    dtUsuarios = objUsuariosBll.ConsultaRapidaSupervisoresBll();

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado

                        lblSupervisores.Text = dtUsuarios.Rows[0]["Supervisores"].ToString();
                    }
                    else
                    {
                        alertError.Attributes.Add("style", "display:none");

                    }
                    dtUsuarios = objUsuariosBll.ConsultaRapidaVigilantesBll();

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado

                        lblVigilantes.Text = dtUsuarios.Rows[0]["Vigilantes"].ToString();
                    }
                    else
                    {
                        alertError.Attributes.Add("style", "display:none");

                    }
                    dtUsuarios = objUsuariosBll.ConsultaRapidaClientesBll();

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado

                        lblClientes.Text = dtUsuarios.Rows[0]["Clientes"].ToString();
                    }
                    else
                    {
                        alertError.Attributes.Add("style", "display:none");

                    }
                    dtUsuarios = objUsuariosBll.ConsultaRapidaRestriccionesBll();

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado

                        lblRestriccion.Text = dtUsuarios.Rows[0]["descripcion"].ToString();
                    }
                    else
                    {
                        alertError.Attributes.Add("style", "display:none");

                    }
                    dtUsuarios = objUsuariosBll.ConsultaRapidaSancionesBll();

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado

                        lblSancionados.Text = dtUsuarios.Rows[0]["Sanciones"].ToString();
                    }
                    else
                    {
                        alertError.Attributes.Add("style", "display:none");

                    }

                }

                catch (Exception ex)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "se presento un error al listar los registros :" + ex.Message.ToString();
                }
            }
        }        
    }
}