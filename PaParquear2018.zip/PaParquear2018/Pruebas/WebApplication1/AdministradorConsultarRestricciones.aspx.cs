﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class AdministradorConsultarRestricciones : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                if (sesion != 1)
                {
                    Response.Redirect("Index.aspx", false);
                }

            }
            catch 
            {
                Response.Redirect("Index.aspx");
            }
            alertError.Attributes.Add("style", "display:none");
        }

        protected void BtnActivas_Click(object sender, EventArgs e)
        {
            try
            {
                //llamo al metodo limpiar controles

                //LimpiarControles();
                //creamos el datatable para recibir la informacion 
                DataTable dtUsuarios = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();

                //llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
                dtUsuarios = objUsuariosBll.getRestriccionesActivasBll();

                //seleccionamos el origen de datos para el datagriview
                GVRestricciones.DataSource = dtUsuarios;
                GVRestricciones.DataBind();
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "se presento un error al listar los registros :" + ex.Message.ToString();
            }
            finally
            {

            }
        }

        protected void BtnMostrar_Click(object sender, EventArgs e)
        {
            try
            {
                //llamo al metodo limpiar controles

                //LimpiarControles();
                //creamos el datatable para recibir la informacion 
                DataTable dtUsuarios = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();

                //llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
                dtUsuarios = objUsuariosBll.getAllRestriccionesBll();

                //seleccionamos el origen de datos para el datagriview
                GVRestricciones.DataSource = dtUsuarios;
                GVRestricciones.DataBind();
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "se presento un error al listar los registros :" + ex.Message.ToString();
            }
            finally
            {

            }
        }
    }
}