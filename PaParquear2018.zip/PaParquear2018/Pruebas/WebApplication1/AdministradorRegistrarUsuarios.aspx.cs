﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class Administrador : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            oculto.Visible = false;
            oculto2.Visible = false;
            oVigilantes.Visible = false;
            oClientes.Visible = false;
            try
            {
                Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                if (sesion != 1)
                {
                    Response.Redirect("Index.aspx", false);
                }

            }
            catch
            {
                Response.Redirect("Index.aspx");
            }

            if (!IsPostBack)
            {
                alertError.Attributes.Add("style", "display:none");
                alertSuccess.Attributes.Add("style", "display:none");
                DataTable dtUsuarios = new DataTable();

                AdministradorBll objUsuariosBll = new AdministradorBll();

                dtUsuarios = objUsuariosBll.llenarUsuariosBll();
                DDLidRol.DataSource = dtUsuarios;
                DDLidRol.DataTextField = "descripcion";
                DDLidRol.DataValueField = "id_rol";
                DDLidRol.DataBind();

                txtContraseña.Focus();
            }
        }

        private void Limpiar()
        {
            txtIdentificacion.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtDireccion.Text = "";
            txtTelefono.Text = "";
            txtContraseña.Text = "";
            txtRespuestaSeguridad.Text = "";
            txtMatricula.Text = "";
            txtModelo.Text = "";
            txtColor.Text = "";
            txtEmail.Text = "";
            lblSucces.Text = "";
            LblError.Text = "";
            Lblaviso.Text = "";
        }

        protected void BtnAgregar_Click(object sender, EventArgs e)
        {
            try
            {

                //int id_Usuario = Convert.ToInt32(HdfId_Usuario.Value);
                string identificacion = txtIdentificacion.Text;
                string Nom_Usuario = txtNombre.Text;
                string Apelli_Usuario = txtApellido.Text;
                string Dir_Usuario = txtDireccion.Text;
                string Tel_Usuario = txtTelefono.Text;
                int id_rol = int.Parse(DDLidRol.SelectedValue);
                string Contraseña = txtContraseña.Text;
                string Correo_Elect = txtEmail.Text;
                string PreguntaSeg = DDLPreguntaSeguridad.SelectedValue;
                string RespuestaSeg = txtRespuestaSeguridad.Text;
                int Estado = 1;
                string Matricula = txtMatricula.Text;
                string Modelo = txtModelo.Text;
                string Color = txtColor.Text;

                DataTable dtValidacionI = new DataTable();
                DataTable dtValidacionT = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();
                dtValidacionI = objUsuariosBll.ValidarIdentificacion(identificacion);
                dtValidacionT = objUsuariosBll.ValidarTelefono(Tel_Usuario);

                if (dtValidacionI.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    Lblaviso.Text = "Identificacion ya existe";

                }
                else if (dtValidacionT.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    Lblaviso.Text = "Numero Telefonico ya existe";
                }

                else
                {
                    // creo una variable que reciba el resultasp dep query
                    string Resultado;

                    //invoco el metodo en Bll insertMecanico
                    Resultado = objUsuariosBll.AutoRegistroBll(identificacion, Nom_Usuario, Apelli_Usuario, Dir_Usuario,
                    Tel_Usuario, id_rol, Contraseña, Correo_Elect, PreguntaSeg, RespuestaSeg, Estado, Matricula, Modelo, Color);

                    if (Resultado == "OK")
                    {
                        //alertError.Attributes.Add("style", "display:blok");
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSucces.Text = "Usuario insertado correctamente";
                    }

                }
            }
            catch (Exception ex)
            {
                //alertError.Attributes.Add("style", "display:blok");
                LblError.Text = "Se presento un error al insertar el Usuario. Detalle error : " + ex.Message.ToString();

            }
        }

        protected void ActivarRol_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(DDLidRol.SelectedValue) == 1)
            {
                oAdminSupervisor.Visible = true;
                oClientes.Visible = false;
                oVigilantes.Visible = false;
                Limpiar();

            }
            if (Convert.ToInt32(DDLidRol.SelectedValue) == 2)
            {
                oAdminSupervisor.Visible = true;
                oClientes.Visible = false;
                oVigilantes.Visible = false;
                Limpiar();

            }
            if (Convert.ToInt32(DDLidRol.SelectedValue) == 3)
            {
                oculto.Visible = true;
                oVigilantes.Visible = true;
                oClientes.Visible = false;
                oAdminSupervisor.Visible = false;
                Limpiar();

            }
            if (Convert.ToInt32(DDLidRol.SelectedValue) == 4)
            {
                oculto2.Visible = true;
                oClientes.Visible = true;
                oAdminSupervisor.Visible = false;
                oVigilantes.Visible = false;
                Limpiar();

            }
        }

        protected void BtnAgregarAS_Click(object sender, EventArgs e)
        {
            try
            {

                //int id_Usuario = Convert.ToInt32(HdfId_Usuario.Value);
                string identificacion = txtIdentificacion.Text;
                string Nom_Usuario = txtNombre.Text;
                string Apelli_Usuario = txtApellido.Text;
                string Dir_Usuario = txtDireccion.Text;
                string Tel_Usuario = txtTelefono.Text;
                int id_rol = int.Parse(DDLidRol.SelectedValue);
                string Contraseña = txtContraseña.Text;
                string Correo_Elect = txtEmail.Text;
                string PreguntaSeg = DDLPreguntaSeguridad.SelectedValue;
                string RespuestaSeg = txtRespuestaSeguridad.Text;
                int Estado = 1;

                DataTable dtValidacionI = new DataTable();
                DataTable dtValidacionT = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();
                dtValidacionI = objUsuariosBll.ValidarIdentificacion(identificacion);
                dtValidacionT = objUsuariosBll.ValidarTelefono(Tel_Usuario);

                if (dtValidacionI.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    Lblaviso.Text = "Identificacion ya existe";

                }
                else if (dtValidacionT.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    Lblaviso.Text = "Numero Telefonico ya existe";
                }

                else
                {
                    // creo una variable que reciba el resultasp dep query
                    string Resultado;

                    //invoco el metodo en Bll insertMecanico
                    Resultado = objUsuariosBll.insertar_AdminSupervisorBll(identificacion, Nom_Usuario, Apelli_Usuario, Dir_Usuario,
                    Tel_Usuario, id_rol, Contraseña, Correo_Elect, PreguntaSeg, RespuestaSeg, Estado);

                    if (Resultado == "OK")
                    {
                        //alertError.Attributes.Add("style", "display:blok");
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSucces.Text = "Usuario insertado correctamente";
                    }

                }
            }
            catch (Exception ex)
            {
                //alertError.Attributes.Add("style", "display:blok");
                LblError.Text = "Se presento un error al insertar el Usuario. Detalle error : " + ex.Message.ToString();

            }
        }

        protected void BtnAgregarV_Click(object sender, EventArgs e)
        {
            try
            {

                //int id_Usuario = Convert.ToInt32(HdfId_Usuario.Value);
                string identificacion = txtIdentificacion.Text;
                string Nom_Usuario = txtNombre.Text;
                string Apelli_Usuario = txtApellido.Text;
                string Dir_Usuario = txtDireccion.Text;
                string Tel_Usuario = txtTelefono.Text;
                int id_rol = int.Parse(DDLidRol.SelectedValue);
                string Contraseña = txtContraseña.Text;
                string Correo_Elect = txtEmail.Text;
                int Turno = Convert.ToInt32(DDLTurno.SelectedValue);
                string PreguntaSeg = DDLPreguntaSeguridad.SelectedValue;
                string RespuestaSeg = txtRespuestaSeguridad.Text;
                int Estado = 1;

                DataTable dtValidacionI = new DataTable();
                DataTable dtValidacionT = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();
                dtValidacionI = objUsuariosBll.ValidarIdentificacion(identificacion);
                dtValidacionT = objUsuariosBll.ValidarTelefono(Tel_Usuario);

                if (dtValidacionI.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    Lblaviso.Text = "Identificacion ya existe";

                }
                else if (dtValidacionT.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    Lblaviso.Text = "Numero Telefonico ya existe";
                }

                else
                {
                    // creo una variable que reciba el resultasp dep query
                    string Resultado;

                    //invoco el metodo en Bll insertMecanico
                    Resultado = objUsuariosBll.insertar_VigilantesBll(identificacion, Nom_Usuario, Apelli_Usuario, Dir_Usuario,
                    Tel_Usuario, id_rol, Contraseña, Correo_Elect, Turno, PreguntaSeg, RespuestaSeg, Estado);

                    if (Resultado == "OK")
                    {
                        //alertError.Attributes.Add("style", "display:blok");
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSucces.Text = "Usuario insertado correctamente";
                    }

                }
            }
            catch (Exception ex)
            {
                //alertError.Attributes.Add("style", "display:blok");
                LblError.Text = "Se presento un error al insertar el Usuario. Detalle error : " + ex.Message.ToString();

            }
        }
    }
}