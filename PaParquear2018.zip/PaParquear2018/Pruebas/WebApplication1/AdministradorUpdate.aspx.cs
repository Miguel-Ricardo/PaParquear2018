﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class AdministradorUpdate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            oculto.Visible = false;
            oculto2.Visible = false;
            ocultoA1.Visible = false;
            ocultoA2.Visible = false;
            BtnBuscar.Visible = false;
            BtnBuscarVigilantes.Visible = false;
            Datos.Visible = false;
            limpiar();
            try
            {
                Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                if (sesion != 1)
                {
                    Response.Redirect("Index.aspx", false);
                }

            }
            catch 
            {
                Response.Redirect("Index.aspx");
            }

            if (!IsPostBack)
            {
                alertError.Attributes.Add("style", "display:none");

                txtContraseña.Focus();
                DataTable dtUsuarios = new DataTable();

                AdministradorBll objUsuariosBll = new AdministradorBll();

                dtUsuarios = objUsuariosBll.llenarUsuariosBll();
                DDLidRol.DataSource = dtUsuarios;
                DDLidRol.DataTextField = "descripcion";
                DDLidRol.DataValueField = "id_rol";
                DDLidRol.DataBind();
            }
        }

        private void limpiar()
        {

            GvUsuarios.DataSource = null;
            GvUsuarios.DataBind();


        }
        protected void BtnActualizar_Click(object sender, EventArgs e)
        {
            try
            {

                AdministradorBll objUsuariosBll = new AdministradorBll();

                //int id_Usuario = Convert.ToInt32(HdfId_Usuario.Value);
                string identificacion = txtIdentificacion.Text;
                string Dir_Usuario = txtDireccion.Text;
                string Tel_Usuario = txtTelefono.Text;
                string Contraseña = txtContraseña.Text;
                string Correo_Elect = txtEmail.Text;
                string PreguntaSeg = DDLPreguntaSeguridad.SelectedValue;
                string RespuestaSeg = txtRespuestaSeguridad.Text;
                string Matricula = txtMatricula.Text;
                string Modelo = txtModelo.Text;
                string Color = txtColor.Text;

                // creo una variable que reciba el resultasp dep query
                string Resultado;

                //invoco el metodo en Bll insertMecanico
                Resultado = objUsuariosBll.Modificar_UsuariosBll(identificacion, Dir_Usuario,
                Tel_Usuario, Contraseña, Correo_Elect,PreguntaSeg, RespuestaSeg, Matricula, Modelo, Color);

                if (Resultado == "OK")
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El Usuario se Modifico correctamente";
                    limpiar();

                }

            }
            catch (Exception)
            {

                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presento un error al Modificar el Vehiculo. Detalle error : ";

            }       
        }

        protected void BtnBuscar_Click(object sender, EventArgs e)
        {
            
            try
            {
                Lblaviso.Text = "";
                LblError.Text = "";
                Datos.Visible = true;
                oculto.Visible = false;
                oculto2.Visible = true;
                ocultoA1.Visible = true;
                ocultoA2.Visible = false;
                ocultoA3.Visible = false;
                //llamo al metodo limpiar controles

                //LimpiarControles();
                //creamos el datatable para recibir la informacion 
                DataTable dtUsuarios = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();
                int identificacion = int.Parse(txtIdentificacion.Text);

                //llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
                dtUsuarios = objUsuariosBll.getClientesBll(identificacion);

                //seleccionamos el origen de datos para el datagriview
                GvUsuarios.DataSource = dtUsuarios;
                GvUsuarios.DataBind();

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblLlenarNombre.Text = dtUsuarios.Rows[0]["Nombre_Completo"].ToString();
                    txtDireccion.Text = dtUsuarios.Rows[0]["Dir_Persona"].ToString();
                    txtTelefono.Text = dtUsuarios.Rows[0]["Tel_Persona"].ToString();
                    txtContraseña.Text = dtUsuarios.Rows[0]["Contraseña"].ToString();
                    txtEmail.Text = dtUsuarios.Rows[0]["Correo_Persona"].ToString();
                    txtRespuestaSeguridad.Text = dtUsuarios.Rows[0]["RespuestaSeg"].ToString();
                    txtMatricula.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    txtModelo.Text = dtUsuarios.Rows[0]["Modelo_Vehi"].ToString();
                    txtColor.Text = dtUsuarios.Rows[0]["Color_Vehi"].ToString();
                }
                else
                {
                    alertError.Attributes.Add("style", "display:none");

                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "se presento un error al listar los registros :" + ex.Message.ToString();
            }
            finally
            {

            }
        }

        protected void BtnActualizarVigilantes_Click(object sender, EventArgs e)
        {
            try
            {
                AdministradorBll objUsuariosBll = new AdministradorBll();

                //int id_Usuario = Convert.ToInt32(HdfId_Usuario.Value);
                string identificacion = txtIdentificacion.Text;
                string Dir_Usuario = txtDireccion.Text;
                string Tel_Usuario = txtTelefono.Text;
                string Contraseña = txtContraseña.Text;
                string Correo_Elect = txtEmail.Text;
                int Turno = Convert.ToInt32(DDLTurno.SelectedValue);
                string PreguntaSeg = DDLPreguntaSeguridad.SelectedValue;
                string RespuestaSeg = txtRespuestaSeguridad.Text;

                string Resultado;

                //invoco el metodo en Bll insertMecanico
                Resultado = objUsuariosBll.Modificar_VigilantesBll(identificacion, Dir_Usuario,
                Tel_Usuario, Contraseña, Correo_Elect, Turno, PreguntaSeg, RespuestaSeg);

                if (Resultado == "OK")
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El Usuario se Modifico correctamente";
                    limpiar();

                }

            }
            catch (Exception)
            {

                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presento un error al Modificar el Vehiculo. Detalle error : ";

            }
        }

        protected void BtnActualizarSupervisor_Click(object sender, EventArgs e)
        {
            try
            {
                
                AdministradorBll objUsuariosBll = new AdministradorBll();

                //int id_Usuario = Convert.ToInt32(HdfId_Usuario.Value);
                string identificacion = txtIdentificacion.Text;
                string Dir_Usuario = txtDireccion.Text;
                string Tel_Usuario = txtTelefono.Text;
                string Contraseña = txtContraseña.Text;
                string Correo_Elect = txtEmail.Text;
                string PreguntaSeg = DDLPreguntaSeguridad.SelectedValue;
                string RespuestaSeg = txtRespuestaSeguridad.Text;

                string Resultado;

                //invoco el metodo en Bll insertMecanico
                Resultado = objUsuariosBll.Modificar_SupervisoresBll(identificacion, Dir_Usuario,
                Tel_Usuario, Contraseña, Correo_Elect, PreguntaSeg, RespuestaSeg);

                if (Resultado == "OK")
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El Usuario se Modifico correctamente";
                    limpiar();

                }

            }
            catch (Exception)
            {

                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presento un error al Modificar el Vehiculo. Detalle error : ";

            }
        }

        protected void ActivarRol_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(DDLidRol.SelectedValue) == 1)
            {                
                buscarOtros.Visible = true;
                BtnBuscar.Visible = false;
                BtnBuscarVigilantes.Visible = false;
            }
            if (Convert.ToInt32(DDLidRol.SelectedValue) == 2)
            {                
                buscarOtros.Visible = true;
                BtnBuscar.Visible = false;
                BtnBuscarVigilantes.Visible = false;
            }
            if (Convert.ToInt32(DDLidRol.SelectedValue) == 3)
            {            
                buscarOtros.Visible = false;
                BtnBuscar.Visible = false;
                BtnBuscarVigilantes.Visible = true;
            }
            if (Convert.ToInt32(DDLidRol.SelectedValue) == 4)
            {                
                BtnBuscar.Visible = true;
                btnBuscarOtros.Visible = false;
                BtnBuscarVigilantes.Visible = false;
            }
        }


        protected void btnBuscarOtros_Click(object sender, EventArgs e)
        {
            try
            {
                Lblaviso.Text = "";
                LblError.Text = "";
                Datos.Visible = true;
                oculto2.Visible = false;
                oculto.Visible = true;
                ocultoA3.Visible = true;
                ocultoA2.Visible = false;
                ocultoA1.Visible = false;
                //llamo al metodo limpiar controles

                //creamos el datatable para recibir la informacion 
                DataTable dtUsuarios = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();
                int identificacion = int.Parse(txtIdentificacion.Text);

                //llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
                dtUsuarios = objUsuariosBll.getUsuariosBll(identificacion);

                //seleccionamos el origen de datos para el datagriview
                GvUsuarios.DataSource = dtUsuarios;
                GvUsuarios.DataBind();

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblLlenarNombre.Text = dtUsuarios.Rows[0]["Nombre_Completo"].ToString();
                    txtDireccion.Text = dtUsuarios.Rows[0]["Dir_Persona"].ToString();
                    txtTelefono.Text = dtUsuarios.Rows[0]["Tel_Persona"].ToString();
                    txtContraseña.Text = dtUsuarios.Rows[0]["Contraseña"].ToString();
                    txtEmail.Text = dtUsuarios.Rows[0]["Correo_Persona"].ToString();
                    txtRespuestaSeguridad.Text = dtUsuarios.Rows[0]["RespuestaSeg"].ToString();
                }
                else
                {
                    alertError.Attributes.Add("style", "display:none");

                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "se presento un error al listar los registros :" + ex.Message.ToString();
            }
            finally
            {

            }
        }

        protected void BtnBuscarVigilantes_Click(object sender, EventArgs e)
        {
            try
            {
                Lblaviso.Text = "";
                LblError.Text = "";
                Datos.Visible = true;
                oculto2.Visible = false;
                oculto.Visible = true;
                ocultoA3.Visible = false;
                ocultoA2.Visible = true;
                ocultoA1.Visible = false;
                //llamo al metodo limpiar controles

                //creamos el datatable para recibir la informacion 
                DataTable dtUsuarios = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();
                int identificacion = int.Parse(txtIdentificacion.Text);

                //llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
                dtUsuarios = objUsuariosBll.getUsuariosBll(identificacion);

                //seleccionamos el origen de datos para el datagriview
                GvUsuarios.DataSource = dtUsuarios;
                GvUsuarios.DataBind();

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblLlenarNombre.Text = dtUsuarios.Rows[0]["Nombre_Completo"].ToString();
                    txtDireccion.Text = dtUsuarios.Rows[0]["Dir_Persona"].ToString();
                    txtTelefono.Text = dtUsuarios.Rows[0]["Tel_Persona"].ToString();
                    txtContraseña.Text = dtUsuarios.Rows[0]["Contraseña"].ToString();
                    txtEmail.Text = dtUsuarios.Rows[0]["Correo_Persona"].ToString();
                    txtRespuestaSeguridad.Text = dtUsuarios.Rows[0]["RespuestaSeg"].ToString();
                }
                else
                {
                    alertError.Attributes.Add("style", "display:none");

                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "se presento un error al listar los registros :" + ex.Message.ToString();
            }
            finally
            {

            }
        }
    }
}