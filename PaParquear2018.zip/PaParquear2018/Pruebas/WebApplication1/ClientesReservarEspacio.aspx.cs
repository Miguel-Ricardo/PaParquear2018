﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class ClientesReservarEspacio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                if (sesion != 1)
                {
                    Response.Redirect("Index.aspx", false);
                }

            }
            catch
            {
                Response.Redirect("Index.aspx");
            }
            if (!IsPostBack)
            {
                Limpiar();
                alertError.Attributes.Add("style", "display:none");
                alertSuccess.Attributes.Add("style", "display:none");
                CargarUsuarios();
                //lblIdVehiculo1.Visible = false;

                DataTable dtLoguin = new DataTable();

                LoginBll objLoguin = new LoginBll();

                dtLoguin = objLoguin.verificarEspacios();


                if (dtLoguin.Rows.Count > 0)
                {

                    if (dtLoguin.Rows[0][0].ToString() == "1")
                    {
                        if (dtLoguin.Rows[0][1].ToString() == "")
                        {
                            lblReservado1.Visible = false;
                        }
                        else
                        {
                            lblReservado1.Visible = true;
                            BtnAsignar1.Visible = false;
                            lblEspacio1.Text = dtLoguin.Rows[0]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[1][0].ToString() == "2")
                    {
                        if (dtLoguin.Rows[1][1].ToString() == "")
                        {
                            lblReservado2.Visible = false;
                        }
                        else
                        {
                            lblReservado2.Visible = true;
                            BtnAsignar2.Visible = false;
                            lblEspacio2.Text = dtLoguin.Rows[1]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[2][0].ToString() == "3")
                    {
                        if (dtLoguin.Rows[2][1].ToString() == "")
                        {
                            lblReservado3.Visible = false;
                        }
                        else
                        {
                            lblReservado3.Visible = true;
                            BtnAsignar3.Visible = false;
                            lblEspacio3.Text = dtLoguin.Rows[2]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[3][0].ToString() == "4")
                    {
                        if (dtLoguin.Rows[3][1].ToString() == "")
                        {
                            lblReservado4.Visible = false;
                        }
                        else
                        {
                            lblReservado4.Visible = true;
                            BtnAsignar4.Visible = false;
                            lblEspacio4.Text = dtLoguin.Rows[3]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[4][0].ToString() == "5")
                    {
                        if (dtLoguin.Rows[4][1].ToString() == "")
                        {
                            lblReservado5.Visible = false;
                        }
                        else
                        {
                            lblReservado5.Visible = true;
                            BtnAsignar5.Visible = false;
                            lblEspacio5.Text = dtLoguin.Rows[4]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[5][0].ToString() == "6")
                    {
                        if (dtLoguin.Rows[5][1].ToString() == "")
                        {
                            lblReservado6.Visible = false;
                        }
                        else
                        {
                            lblReservado6.Visible = true;
                            BtnAsignar6.Visible = false;
                            lblEspacio6.Text = dtLoguin.Rows[5]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[6][0].ToString() == "7")
                    {
                        if (dtLoguin.Rows[6][1].ToString() == "")
                        {
                            lblReservado7.Visible = false;
                        }
                        else
                        {
                            lblReservado7.Visible = true;
                            BtnAsignar7.Visible = false;
                            lblEspacio7.Text = dtLoguin.Rows[6]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[7][0].ToString() == "8")
                    {
                        if (dtLoguin.Rows[7][1].ToString() == "")
                        {
                            lblReservado8.Visible = false;
                        }
                        else
                        {
                            lblReservado8.Visible = true;
                            BtnAsignar8.Visible = false;
                            lblEspacio8.Text = dtLoguin.Rows[7]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[8][0].ToString() == "9")
                    {
                        if (dtLoguin.Rows[8][1].ToString() == "")
                        {
                            lblReservado9.Visible = false;
                        }
                        else
                        {
                            lblReservado9.Visible = true;
                            BtnAsignar9.Visible = false;
                            lblEspacio9.Text = dtLoguin.Rows[8]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[9][0].ToString() == "10")
                    {
                        if (dtLoguin.Rows[9][1].ToString() == "")
                        {
                            lblReservado10.Visible = false;
                        }
                        else
                        {
                            lblReservado10.Visible = true;
                            BtnAsignar10.Visible = false;
                            lblEspacio10.Text = dtLoguin.Rows[9]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[10][0].ToString() == "11")
                    {
                        if (dtLoguin.Rows[10][1].ToString() == "")
                        {
                            lblReservado11.Visible = false;
                        }
                        else
                        {
                            lblReservado11.Visible = true;
                            BtnAsignar11.Visible = false;
                            lblEspacio11.Text = dtLoguin.Rows[10]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[11][0].ToString() == "12")
                    {
                        if (dtLoguin.Rows[11][1].ToString() == "")
                        {
                            lblReservado12.Visible = false;
                        }
                        else
                        {
                            lblReservado12.Visible = true;
                            BtnAsignar12.Visible = false;
                            lblEspacio12.Text = dtLoguin.Rows[11]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[12][0].ToString() == "13")
                    {
                        if (dtLoguin.Rows[12][1].ToString() == "")
                        {
                            lblReservado13.Visible = false;
                        }
                        else
                        {
                            lblReservado13.Visible = true;
                            BtnAsignar13.Visible = false;
                            lblEspacio13.Text = dtLoguin.Rows[12]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[13][0].ToString() == "14")
                    {
                        if (dtLoguin.Rows[13][1].ToString() == "")
                        {
                            lblReservado14.Visible = false;
                        }
                        else
                        {
                            lblReservado14.Visible = true;
                            BtnAsignar14.Visible = false;
                            lblEspacio14.Text = dtLoguin.Rows[13]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[14][0].ToString() == "15")
                    {
                        if (dtLoguin.Rows[14][1].ToString() == "")
                        {
                            lblReservado15.Visible = false;
                        }
                        else
                        {
                            lblReservado15.Visible = true;
                            BtnAsignar15.Visible = false;
                            lblEspacio15.Text = dtLoguin.Rows[14]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[15][0].ToString() == "16")
                    {
                        if (dtLoguin.Rows[15][1].ToString() == "")
                        {
                            lblReservado16.Visible = false;
                        }
                        else
                        {
                            lblReservado16.Visible = true;
                            BtnAsignar16.Visible = false;
                            lblEspacio16.Text = dtLoguin.Rows[15]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[16][0].ToString() == "17")
                    {
                        if (dtLoguin.Rows[16][1].ToString() == "")
                        {
                            lblReservado17.Visible = false;
                        }
                        else
                        {
                            lblReservado17.Visible = true;
                            BtnAsignar17.Visible = false;
                            lblEspacio17.Text = dtLoguin.Rows[16]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[17][0].ToString() == "18")
                    {
                        if (dtLoguin.Rows[17][1].ToString() == "")
                        {
                            lblReservado18.Visible = false;
                        }
                        else
                        {
                            lblReservado18.Visible = true;
                            BtnAsignar18.Visible = false;
                            lblEspacio18.Text = dtLoguin.Rows[17]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[18][0].ToString() == "19")
                    {
                        if (dtLoguin.Rows[18][1].ToString() == "")
                        {
                            lblReservado19.Visible = false;
                        }
                        else
                        {
                            lblReservado19.Visible = true;
                            BtnAsignar19.Visible = false;
                            lblEspacio19.Text = dtLoguin.Rows[18]["Matricula_Vehi"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[19][0].ToString() == "20")
                    {
                        if (dtLoguin.Rows[19][1].ToString() == "")
                        {
                            lblReservado20.Visible = false;
                        }
                        else
                        {
                            lblReservado20.Visible = true;
                            BtnAsignar20.Visible = false;
                            lblEspacio20.Text = dtLoguin.Rows[19]["Matricula_Vehi"].ToString();
                        }
                    }

                }
            }
        }

        private void CargarUsuarios()
        {
            DataTable dtUsuarios = new DataTable();

            VigilanteBll objUsuariosBll = new VigilanteBll();

            dtUsuarios = objUsuariosBll.getMatriculaBll();
            DDLMatricula.DataSource = dtUsuarios;
            DDLMatricula.DataTextField = "Matricula_Vehi";
            DDLMatricula.DataValueField = "id_Vehi";
            DDLMatricula.DataBind();
        }

        private void Limpiar()
        {
            LblError.Text = "";
            lblSuccess.Text = "";
            LblErrorRestriccion.Text = "";
            lblSuccessRestriccion.Text = "";
            LblErrorSancion.Text = "";
            LblSuccessSancion.Text = "";
            alertError.Attributes.Add("style", "display:none");
            alertSuccess.Attributes.Add("style", "display:none");
        }

        protected void BtnRYS_Click(object sender, EventArgs e)
        {
            Limpiar();
            DataTable dtVigilantes = new DataTable();
            //Crear e instanciamos un objeto de la clase MecanicosBll
            VigilanteBll oVigilantes = new VigilanteBll();
            //Llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
            dtVigilantes = oVigilantes.getEstadoRestriccionBll();

            if (dtVigilantes.Rows.Count > 0)
            {

                if (dtVigilantes.Rows[0][0].ToString() == "1")
                {
                    if (DDLMatricula.SelectedValue.EndsWith("2") | DDLMatricula.SelectedValue.EndsWith("4") | DDLMatricula.SelectedValue.EndsWith("6") | DDLMatricula.SelectedValue.EndsWith("8"))
                    {
                        alertError.Attributes.Add("style", "display:block");
                        LblErrorRestriccion.Text = "No se admiten placan que terminen en impar";

                    }
                    else
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccessRestriccion.Text = "Permitido";
                    }
                }
                else if (dtVigilantes.Rows[0][0].ToString() == "0")
                {
                    if (DDLMatricula.SelectedValue.EndsWith("1") | DDLMatricula.SelectedValue.EndsWith("3") | DDLMatricula.SelectedValue.EndsWith("5") | DDLMatricula.SelectedValue.EndsWith("7") | DDLMatricula.SelectedValue.EndsWith("9"))
                    {
                        alertError.Attributes.Add("style", "display:block");
                        LblErrorRestriccion.Text = "No se admiten placan que terminen en spar";
                    }
                    else
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccessRestriccion.Text = "Permitido";
                    }
                }

            }
            else
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Placa no registrada";

            }

            DataTable dtSanciones = new DataTable();
            //Crear e instanciamos un objeto de la clase MecanicosBll
            VigilanteBll oSanciones = new VigilanteBll();
            //Creamos la variable
            string Matricula = DDLMatricula.SelectedValue;
            //Llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
            dtSanciones = oSanciones.getSancionesClientesBll(Matricula);

            if (dtSanciones.Rows.Count > 0)
            {
                alertError.Attributes.Add("style", "display:block");
                LblErrorSancion.Text = "El cliente esta sancionado";
            }
            else
            {
                alertSuccess.Attributes.Add("style", "display:block");
                LblSuccessSancion.Text = "El cliente no tiene sanciones";

            }
        }

        protected void BtnAsignar1_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar1.Visible = false;
                lblReservado1.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 1;


                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo1.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio1.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar2_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar2.Visible = false;
                lblReservado2.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 2;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo2.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio2.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar3_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar3.Visible = false;
                lblReservado3.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 3;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo3.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio3.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar4_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar4.Visible = false;
                lblReservado4.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 4;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo4.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio4.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar5_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar5.Visible = false;
                lblReservado5.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 5;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo5.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio5.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar6_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar6.Visible = false;
                lblReservado6.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 6;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo6.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio6.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar7_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar7.Visible = false;
                lblReservado7.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 7;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo7.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio7.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar8_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar8.Visible = false;
                lblReservado8.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 8;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo8.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio8.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar9_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar9.Visible = false;
                lblReservado9.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 9;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo9.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio9.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar10_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar10.Visible = false;
                lblReservado10.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 10;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo10.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio10.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar11_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar11.Visible = false;
                lblReservado11.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 11;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo11.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio11.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar12_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar12.Visible = false;
                lblReservado12.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 12;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo12.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio12.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar13_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar13.Visible = false;
                lblReservado13.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 13;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo13.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio13.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar14_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar14.Visible = false;
                lblReservado14.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 14;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo14.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio14.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar15_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar15.Visible = false;
                lblReservado15.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 15;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo15.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio15.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar16_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar16.Visible = false;
                lblReservado16.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 16;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo16.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio16.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar17_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar17.Visible = false;
                lblReservado17.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 17;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo17.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio17.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar18_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar18.Visible = false;
                lblReservado18.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 18;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo18.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio18.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar19_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar19.Visible = false;
                lblReservado19.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 19;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo19.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio19.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnAsignar20_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar20.Visible = false;
                lblReservado20.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 20;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Ingreso de vehiculo registrado";
                    lblSuccess.Visible = true;
                }

                dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                if (dtVigilantes.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblIdVehiculo20.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                }

                dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblEspacio20.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
            }
        }

        protected void BtnRYS_Click1(object sender, EventArgs e)
        {
            Limpiar();
            DataTable dtVigilantes = new DataTable();
            //Crear e instanciamos un objeto de la clase MecanicosBll
            VigilanteBll oVigilantes = new VigilanteBll();
            //Llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
            dtVigilantes = oVigilantes.getEstadoRestriccionBll();

            if (dtVigilantes.Rows.Count > 0)
            {

                if (dtVigilantes.Rows[0][0].ToString() == "1")
                {
                    if (DDLMatricula.SelectedValue.EndsWith("2") | DDLMatricula.SelectedValue.EndsWith("4") | DDLMatricula.SelectedValue.EndsWith("6") | DDLMatricula.SelectedValue.EndsWith("8"))
                    {
                        alertError.Attributes.Add("style", "display:block");
                        LblErrorRestriccion.Text = "No se admiten placan que terminen en impar";

                    }
                    else
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccessRestriccion.Text = "Permitido";
                    }
                }
                else if (dtVigilantes.Rows[0][0].ToString() == "0")
                {
                    if (DDLMatricula.SelectedValue.EndsWith("1") | DDLMatricula.SelectedValue.EndsWith("3") | DDLMatricula.SelectedValue.EndsWith("5") | DDLMatricula.SelectedValue.EndsWith("7") | DDLMatricula.SelectedValue.EndsWith("9"))
                    {
                        alertError.Attributes.Add("style", "display:block");
                        LblErrorRestriccion.Text = "No se admiten placan que terminen en spar";
                    }
                    else
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccessRestriccion.Text = "Permitido";
                    }
                }

            }
            else
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Placa no registrada";

            }

            DataTable dtSanciones = new DataTable();
            //Crear e instanciamos un objeto de la clase MecanicosBll
            VigilanteBll oSanciones = new VigilanteBll();
            //Creamos la variable
            string Matricula = DDLMatricula.SelectedValue;
            //Llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
            dtSanciones = oSanciones.getSancionesClientesBll(Matricula);

            if (dtSanciones.Rows.Count > 0)
            {
                alertError.Attributes.Add("style", "display:block");
                LblErrorSancion.Text = "El cliente esta sancionado";
            }
            else
            {
                alertSuccess.Attributes.Add("style", "display:block");
                LblSuccessSancion.Text = "El cliente no tiene sanciones";

            }
        }
    }
}