﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class FormularioWebClientes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                alertError.Attributes.Add("style", "display:none");
                alertSuccess.Attributes.Add("style", "display:none");
            }
        }


        protected void BtnAgregar_Click(object sender, EventArgs e)
        {
            try
            {

                //int id_Usuario = Convert.ToInt32(HdfId_Usuario.Value);
                string identificacion = txtIdentificacion.Text;
                string Nom_Usuario = txtNombre.Text;
                string Apelli_Usuario = txtApellido.Text;
                string Dir_Usuario = txtDireccion.Text;
                string Tel_Usuario = txtTelefono.Text;
                int id_rol = 4;
                string Contraseña = txtContraseña.Text;
                string Correo_Elect = txtEmail.Text;
                string PreguntaSeg = DDLPreguntaSeguridad.SelectedValue;
                string RespuestaSeg = txtRespuestaSeguridad.Text;
                int Estado = 2;
                string Matricula = txtMatricula.Text;
                string Modelo = txtModelo.Text;
                string Color = txtColor.Text;

                DataTable dtValidacionI = new DataTable();
                DataTable dtValidacionT = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();
                dtValidacionI = objUsuariosBll.ValidarIdentificacion(identificacion);
                dtValidacionT = objUsuariosBll.ValidarTelefono(Tel_Usuario);

                if (dtValidacionI.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    Lblaviso.Text = "Identificacion ya existe";

                }
                else if (dtValidacionT.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    Lblaviso.Text = "Numero Telefonico ya existe";
                }

                else
                {
                    // creo una variable que reciba el resultasp dep query
                    string Resultado;

                    //invoco el metodo en Bll insertMecanico
                    Resultado = objUsuariosBll.AutoRegistroBll(identificacion, Nom_Usuario, Apelli_Usuario, Dir_Usuario,
                    Tel_Usuario, id_rol, Contraseña, Correo_Elect, PreguntaSeg, RespuestaSeg, Estado, Matricula, Modelo, Color);

                    if (Resultado == "OK")
                    {
                        //alertError.Attributes.Add("style", "display:blok");
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Usuario insertado correctamente";
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presento un error al insertar el Usuario. Detalle error : " + ex.Message.ToString();

            }
        }
    }
}