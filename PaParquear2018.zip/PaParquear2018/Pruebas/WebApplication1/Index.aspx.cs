﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["SesionActiva"] = 0;
        }

        protected void BtnIngresar_Click(object sender, EventArgs e)
        {
            DataTable dtLoguin = new DataTable();

            LoginBll objLoguin = new LoginBll();

            string Correo_Elect = txtEmail.Text;
            string Contraseña = txtContraseña.Text;

            DataTable dtValidacionVigil = new DataTable();

            VigilanteBll objValidarVigBll = new VigilanteBll();

            dtValidacionVigil = objValidarVigBll.ValidarVigilante(Correo_Elect, Contraseña);



            dtLoguin = objLoguin.VerificarUsuario(Correo_Elect, Contraseña);


            if (dtLoguin.Rows.Count > 0)
            {
                Session["NombreUsuario"] = dtLoguin.Rows[0]["Nom_Persona"].ToString() + " " + dtLoguin.Rows[0]["Apelli_Persona"].ToString();
                Session["SesionActiva"] = 1;
                Session["Rol"] = dtLoguin.Rows[0][0].ToString();

                if (dtLoguin.Rows[0][0].ToString() == "Administrador")
                {
                    Response.Redirect("AdministradorInicio.aspx");
                }
                else if (dtLoguin.Rows[0][0].ToString() == "Supervisor")
                {
                    Response.Redirect("SupervisorInicio.aspx");
                }
                else if ((dtLoguin.Rows[0][0].ToString() == "Vigilante") && (dtValidacionVigil.Rows.Count > 0))
                {
                    Response.Redirect("VigilantesInicio.aspx");
                }
                else if (dtLoguin.Rows[0][0].ToString() == "Cliente")
                {
                    Response.Redirect("ClientesReservarEspacio.aspx");
                }
                else
                {
                    lblError.Text = "NO ESTA EN EL HORARIO CORRESPONDIENTE ";
                }
            }
            else
            {
                lblError.Text = "Contraseña o usario incorrectos";
            }
        }
    }
}