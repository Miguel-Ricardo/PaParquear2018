﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class RecuperarContrasena : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                alertError.Attributes.Add("style", "display:none");
                alertSuccess.Attributes.Add("style", "display:none");
            }
        }

        protected void BtnRecuperar_Click(object sender, EventArgs e)
        {
            try
            {
                RecuperarContraseñaBll objUsuariosBll = new RecuperarContraseñaBll();

                //int id_Usuario = Convert.ToInt32(HdfId_Usuario.Value);
                int Identificacion = int.Parse(txtidentificacion.Text);
                string ContraseñaNueva = txtContraseñaNueva.Text;
                string PreguntaSeg = DDLLogin.SelectedValue;
                string RespuestaSeg = txtRespuestaSeguridad.Text;                

                // creo una variable que reciba el resultasp dep query
                string Resultado;

                //invoco el metodo en Bll insertMecanico
                Resultado = objUsuariosBll.ActualizarContraseñaBll(Identificacion, ContraseñaNueva, PreguntaSeg, RespuestaSeg);

                if (Resultado == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "La contraseña se modifico correctamente";
                    
                }

            }
            catch (Exception)
            {

                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presento un error al Modificar la contraseña. Detalle error : ";

            }
        }
    }
}