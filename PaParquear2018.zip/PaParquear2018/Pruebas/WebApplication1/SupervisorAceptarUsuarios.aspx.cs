﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class SupervisorAceptarUsuarios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                alertError.Attributes.Add("style", "display:none");
                alertInfo.Attributes.Add("style", "display:none");

                try
                {
                    //llamo al metodo limpiar controles

                    //LimpiarControles();
                    //creamos el datatable para recibir la informacion 
                    DataTable dtUsuarios = new DataTable();

                    //creamos e instanciamos un objeto de la clase mecanicosBll
                    SupervisorBll objUsuariosBll = new SupervisorBll();

                    //llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
                    dtUsuarios = objUsuariosBll.getUsuariosFBll();

                    //seleccionamos el origen de datos para el datagriview
                    GvUsuarios.DataSource = dtUsuarios;
                    GvUsuarios.DataBind();

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblInfo.Text = dtUsuarios.Rows[0]["identificacion"].ToString();
                    }
                }
                catch (Exception ex)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "se presento un error al listar los registros :" + ex.Message.ToString();
                }
                finally
                {

                }
            }
        }

        protected void BtnAsignar_Click(object sender, EventArgs e)
        {
            try
            {
                SupervisorBll objUsuariosBll = new SupervisorBll();

                //int id_Usuario = Convert.ToInt32(HdfId_Usuario.Value);
                int identificacion = int.Parse(lblInfo.Text);   

                // creo una variable que reciba el resultasp dep query
                string Resultado;

                //invoco el metodo en Bll insertMecanico
                Resultado = objUsuariosBll.AgregarUsuarioFBll(identificacion);

                if (Resultado == "OK")
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El Usuario se agrego correctamente";

                }

            }
            catch (Exception)
            {

                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presento un error al agregar el cliente. Detalle error : ";

            }
        }

        protected void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                SupervisorBll objUsuariosBll = new SupervisorBll();

                //creo variables para almacenar casa uno de los campos de la caja de texto


                // creo una variable que reciba el resultasp del query
                int identificacion = int.Parse(lblInfo.Text);
                string Resultado;

                //invoco el metodo en Bll insertMecanico
                Resultado = objUsuariosBll.DeleteUsuariosFBll(identificacion);

                if (Resultado == "OK")
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El Usuario se inhabilito correctamente";
                }

            }
            catch (Exception)
            {

                alertError.Attributes.Add("style", "display:blok");
                LblError.Text = "Se presento un error al inhabilitar el Vehiculo. Detalle error : ";

            }
        }
    }
}