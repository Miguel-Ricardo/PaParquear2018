﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class SupervisorAgregarSancion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                if (sesion != 1)
                {
                    Response.Redirect("Index.aspx", false);
                }

            }
            catch 
            {
                Response.Redirect("Index.aspx");
            }

            if (!IsPostBack)
            {
                CargarRestricciones();
                alertError.Attributes.Add("style", "display:none");
                alertSuccess.Attributes.Add("style", "display:none");
            }
        }

        private void CargarRestricciones()
        {
            DataTable dtOrden = new DataTable();

            VigilanteBll ovjMatriculas = new VigilanteBll();

            dtOrden = ovjMatriculas.getMatriculaBll();

            DDLPlaca.DataSource = dtOrden;
            DDLPlaca.DataTextField = "Matricula_Vehi";
            DDLPlaca.DataValueField = "id_Vehi";
            DDLPlaca.DataBind();
        }

        private void LimpiarControles()
        {
            lblaviso.Text ="";
            lblError.Text = "";
            lblSuccess.Text = "";
        }
        

        protected void BtnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                LimpiarControles();

                //Crear e instanciamos un objeto de la clase MecanicosByNitBll
                SupervisorBll objSupervisor = new SupervisorBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                string Nombre_Sancion = txtNombreSancion.Text;
                DateTime Fecha_inicio = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehi = int.Parse(DDLPlaca.SelectedValue);
                int Estado = 1;

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo InsertMecanicoBll
                Retorno = objSupervisor.InsertSancionesBll(Nombre_Sancion, Fecha_inicio,id_Vehi, Estado);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Registro agregado correctamente";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                lblError.Text = "Se presentó un error al insertar el registro. Detaller Error: " + ex.Message.ToString();
            }
        }
    }
}