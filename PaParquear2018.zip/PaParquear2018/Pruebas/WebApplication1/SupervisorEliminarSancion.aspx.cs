﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class SupervisorEliminarSancion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                if (sesion != 1)
                {
                    Response.Redirect("Index.aspx", false);
                }

            }
            catch 
            {
                Response.Redirect("Index.aspx");
            }

            if (!IsPostBack)
            {
                alertError.Attributes.Add("style", "display:none");
                alertInfo.Attributes.Add("style", "display:none");
                alertSuccess.Attributes.Add("style", "display:none");
                CargarVehiculos();
                
            }
        }

        private void CargarVehiculos()
        {
            DataTable dtOrden = new DataTable();

            VigilanteBll ovjMatriculas = new VigilanteBll();

            dtOrden = ovjMatriculas.getMatriculaBll();

            DDLPlaca.DataSource = dtOrden;
            DDLPlaca.DataTextField = "Matricula_Vehi";
            DDLPlaca.DataValueField = "id_Vehi";
            DDLPlaca.DataBind();
        }

        protected void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {

                SupervisorBll objUsuariosBll = new SupervisorBll();

                //creo variables para almacenar casa uno de los campos de la caja de texto

                int id_sancion = int.Parse(lblInfo.Text);


                // creo una variable que reciba el resultasp del query
                string Resultado;

                //invoco el metodo en Bll insertMecanico
                Resultado = objUsuariosBll.DeleteSancionesBll(id_sancion);

                if (Resultado == "OK")
                {
                    alertSuccess.Attributes.Add("style", "display:blok");
                    lblSuccess.Text = "El Usuario se elimino correctamente";
                }

            }
            catch (Exception)
            {

                alertError.Attributes.Add("style", "display:blok");
                LblError.Text = "Se presento un error al eliminar el Vehiculo. Detalle error : ";

            }
        }

        protected void BtnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                //llamo al metodo limpiar controles

                //LimpiarControles();
                //creamos el datatable para recibir la informacion 
                DataTable dtUsuarios = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                SupervisorBll objUsuariosBll = new SupervisorBll();
                int Matricula = int.Parse(DDLPlaca.SelectedValue);

                //llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
                dtUsuarios = objUsuariosBll.getSancionesByMatriculaBll(Matricula);

                //seleccionamos el origen de datos para el datagriview
                GvSanciones.DataSource = dtUsuarios;
                GvSanciones.DataBind();

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                    lblInfo.Text = dtUsuarios.Rows[0]["id_sanciones"].ToString();
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "se presento un error al listar los registros :" + ex.Message.ToString();
            }
            finally
            {

            }
        }
    }
}