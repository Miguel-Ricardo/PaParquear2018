﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;


namespace WebApplication1
{
    public partial class SupervisorEstadoRestriccion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                if (sesion != 1)
                {
                    Response.Redirect("Index.aspx", false);
                }

            }
            catch
            {
                Response.Redirect("Index.aspx");
            }

            if (!IsPostBack)
            {
                alertSuccess.Attributes.Add("style", "display:none");
                alertError.Attributes.Add("style", "display:none");

                DataTable dtUsuarios = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();

                dtUsuarios = objUsuariosBll.ConsultaRapidaRestriccionesBll();

                if (dtUsuarios.Rows.Count > 0)
                {
                    //llenar cada una de las cajas de texto xon los datos del mecanico encontrado

                    lblRestriccion.Text = dtUsuarios.Rows[0]["descripcion"].ToString();
                }
            }

        }

        protected void BtnActivar_Click(object sender, EventArgs e)
        {
            try
            {
                SupervisorBll objUsuariosBll = new SupervisorBll();

                //int id_Usuario = Convert.ToInt32(HdfId_Usuario.Value);

                int estado = int.Parse(DDLPlaca.SelectedValue);

                // creo una variable que reciba el resultasp dep query
                string Resultado;

                //invoco el metodo en Bll insertMecanico
                Resultado = objUsuariosBll.UpdateEstadoBll(estado);

                if (Resultado == "OK")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "El Usuario se Modifico correctamente";

                }

            }
            catch (Exception)
            {

                alertError.Attributes.Add("style", "display:block");
                lblError.Text = "Se presento un error al Modificar el Vehiculo. Detalle error : ";

            }
        }
    }
}