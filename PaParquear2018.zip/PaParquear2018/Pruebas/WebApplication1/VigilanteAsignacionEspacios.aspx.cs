﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class VigilanteAsignacionEspacios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                if (sesion != 1)
                {
                    Response.Redirect("Index.aspx", false);
                }

            }
            catch 
            {
                Response.Redirect("Index.aspx");
            }
            if (!IsPostBack)
            {
                Limpiar();
                alertError.Attributes.Add("style", "display:none");
                alertSuccess.Attributes.Add("style", "display:none");
                CargarUsuarios();
                //lblIdVehiculo1.Visible = false;

                DataTable dtLoguin = new DataTable();

                LoginBll objLoguin = new LoginBll();

                dtLoguin = objLoguin.verificarEspacios();


                if (dtLoguin.Rows.Count > 0)
                {

                    if (dtLoguin.Rows[0][0].ToString() == "1")
                    {
                        if (dtLoguin.Rows[0][1].ToString() == "")
                        {
                            BtnQuitar1.Visible = false;
                        }
                        else
                        {
                            BtnQuitar1.Visible = true;
                            BtnAsignar1.Visible = false;
                            lblEspacio1.Text = dtLoguin.Rows[0]["Matricula_Vehi"].ToString();
                            lblIdVehiculo1.Text = dtLoguin.Rows[0]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[1][0].ToString() == "2")
                    {
                        if (dtLoguin.Rows[1][1].ToString() == "")
                        {
                            BtnQuitar2.Visible = false;
                        }
                        else
                        {
                            BtnQuitar2.Visible = true;
                            BtnAsignar2.Visible = false;
                            lblEspacio2.Text = dtLoguin.Rows[1]["Matricula_Vehi"].ToString();
                            lblIdVehiculo2.Text = dtLoguin.Rows[1]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[2][0].ToString() == "3")
                    {
                        if (dtLoguin.Rows[2][1].ToString() == "")
                        {
                            BtnQuitar3.Visible = false;
                        }
                        else
                        {
                            BtnQuitar3.Visible = true;
                            BtnAsignar3.Visible = false;
                            lblEspacio3.Text = dtLoguin.Rows[2]["Matricula_Vehi"].ToString();
                            lblIdVehiculo3.Text = dtLoguin.Rows[2]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[3][0].ToString() == "4")
                    {
                        if (dtLoguin.Rows[3][1].ToString() == "")
                        {
                            BtnQuitar4.Visible = false;
                        }
                        else
                        {
                            BtnQuitar4.Visible = true;
                            BtnAsignar4.Visible = false;
                            lblEspacio4.Text = dtLoguin.Rows[3]["Matricula_Vehi"].ToString();
                            lblIdVehiculo4.Text = dtLoguin.Rows[3]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[4][0].ToString() == "5")
                    {
                        if (dtLoguin.Rows[4][1].ToString() == "")
                        {
                            BtnQuitar5.Visible = false;
                        }
                        else
                        {
                            BtnQuitar5.Visible = true;
                            BtnAsignar5.Visible = false;
                            lblEspacio5.Text = dtLoguin.Rows[4]["Matricula_Vehi"].ToString();
                            lblIdVehiculo5.Text = dtLoguin.Rows[4]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[5][0].ToString() == "6")
                    {
                        if (dtLoguin.Rows[5][1].ToString() == "")
                        {
                            BtnQuitar6.Visible = false;
                        }
                        else
                        {
                            BtnQuitar6.Visible = true;
                            BtnAsignar6.Visible = false;
                            lblEspacio6.Text = dtLoguin.Rows[5]["Matricula_Vehi"].ToString();
                            lblIdVehiculo6.Text = dtLoguin.Rows[5]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[6][0].ToString() == "7")
                    {
                        if (dtLoguin.Rows[6][1].ToString() == "")
                        {
                            BtnQuitar7.Visible = false;
                        }
                        else
                        {
                            BtnQuitar7.Visible = true;
                            BtnAsignar7.Visible = false;
                            lblEspacio7.Text = dtLoguin.Rows[6]["Matricula_Vehi"].ToString();
                            lblIdVehiculo7.Text = dtLoguin.Rows[6]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[7][0].ToString() == "8")
                    {
                        if (dtLoguin.Rows[7][1].ToString() == "")
                        {
                            BtnQuitar8.Visible = false;
                        }
                        else
                        {
                            BtnQuitar8.Visible = true;
                            BtnAsignar8.Visible = false;
                            lblEspacio8.Text = dtLoguin.Rows[7]["Matricula_Vehi"].ToString();
                            lblIdVehiculo8.Text = dtLoguin.Rows[7]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[8][0].ToString() == "9")
                    {
                        if (dtLoguin.Rows[8][1].ToString() == "")
                        {
                            BtnQuitar9.Visible = false;
                        }
                        else
                        {
                            BtnQuitar9.Visible = true;
                            BtnAsignar9.Visible = false;
                            lblEspacio9.Text = dtLoguin.Rows[8]["Matricula_Vehi"].ToString();
                            lblIdVehiculo9.Text = dtLoguin.Rows[8]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[9][0].ToString() == "10")
                    {
                        if (dtLoguin.Rows[9][1].ToString() == "")
                        {
                            BtnQuitar10.Visible = false;
                        }
                        else
                        {
                            BtnQuitar10.Visible = true;
                            BtnAsignar10.Visible = false;
                            lblEspacio10.Text = dtLoguin.Rows[9]["Matricula_Vehi"].ToString();
                            lblIdVehiculo10.Text = dtLoguin.Rows[9]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[10][0].ToString() == "11")
                    {
                        if (dtLoguin.Rows[10][1].ToString() == "")
                        {
                            BtnQuitar11.Visible = false;
                        }
                        else
                        {
                            BtnQuitar11.Visible = true;
                            BtnAsignar11.Visible = false;
                            lblEspacio11.Text = dtLoguin.Rows[10]["Matricula_Vehi"].ToString();
                            lblIdVehiculo11.Text = dtLoguin.Rows[10]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[11][0].ToString() == "12")
                    {
                        if (dtLoguin.Rows[11][1].ToString() == "")
                        {
                            BtnQuitar12.Visible = false;
                        }
                        else
                        {
                            BtnQuitar12.Visible = true;
                            BtnAsignar12.Visible = false;
                            lblEspacio12.Text = dtLoguin.Rows[11]["Matricula_Vehi"].ToString();
                            lblIdVehiculo12.Text = dtLoguin.Rows[11]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[12][0].ToString() == "13")
                    {
                        if (dtLoguin.Rows[12][1].ToString() == "")
                        {
                            BtnQuitar13.Visible = false;
                        }
                        else
                        {
                            BtnQuitar13.Visible = true;
                            BtnAsignar13.Visible = false;
                            lblEspacio13.Text = dtLoguin.Rows[12]["Matricula_Vehi"].ToString();
                            lblIdVehiculo13.Text = dtLoguin.Rows[12]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[13][0].ToString() == "14")
                    {
                        if (dtLoguin.Rows[13][1].ToString() == "")
                        {
                            BtnQuitar14.Visible = false;
                        }
                        else
                        {
                            BtnQuitar14.Visible = true;
                            BtnAsignar14.Visible = false;
                            lblEspacio14.Text = dtLoguin.Rows[13]["Matricula_Vehi"].ToString();
                            lblIdVehiculo14.Text = dtLoguin.Rows[13]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[14][0].ToString() == "15")
                    {
                        if (dtLoguin.Rows[14][1].ToString() == "")
                        {
                            BtnQuitar15.Visible = false;
                        }
                        else
                        {
                            BtnQuitar15.Visible = true;
                            BtnAsignar15.Visible = false;
                            lblEspacio15.Text = dtLoguin.Rows[14]["Matricula_Vehi"].ToString();
                            lblIdVehiculo15.Text = dtLoguin.Rows[14]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[15][0].ToString() == "16")
                    {
                        if (dtLoguin.Rows[15][1].ToString() == "")
                        {
                            BtnQuitar16.Visible = false;
                        }
                        else
                        {
                            BtnQuitar16.Visible = true;
                            BtnAsignar16.Visible = false;
                            lblEspacio16.Text = dtLoguin.Rows[15]["Matricula_Vehi"].ToString();
                            lblIdVehiculo16.Text = dtLoguin.Rows[15]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[16][0].ToString() == "17")
                    {
                        if (dtLoguin.Rows[16][1].ToString() == "")
                        {
                            BtnQuitar17.Visible = false;
                        }
                        else
                        {
                            BtnQuitar17.Visible = true;
                            BtnAsignar17.Visible = false;
                            lblEspacio17.Text = dtLoguin.Rows[16]["Matricula_Vehi"].ToString();
                            lblIdVehiculo17.Text = dtLoguin.Rows[16]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[17][0].ToString() == "18")
                    {
                        if (dtLoguin.Rows[17][1].ToString() == "")
                        {
                            BtnQuitar18.Visible = false;
                        }
                        else
                        {
                            BtnQuitar18.Visible = true;
                            BtnAsignar18.Visible = false;
                            lblEspacio18.Text = dtLoguin.Rows[17]["Matricula_Vehi"].ToString();
                            lblIdVehiculo18.Text = dtLoguin.Rows[17]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[18][0].ToString() == "19")
                    {
                        if (dtLoguin.Rows[18][1].ToString() == "")
                        {
                            BtnQuitar19.Visible = false;
                        }
                        else
                        {
                            BtnQuitar19.Visible = true;
                            BtnAsignar19.Visible = false;
                            lblEspacio19.Text = dtLoguin.Rows[18]["Matricula_Vehi"].ToString();
                            lblIdVehiculo19.Text = dtLoguin.Rows[18]["id_ingre_sali"].ToString();
                        }
                    }
                    if (dtLoguin.Rows[19][0].ToString() == "20")
                    {
                        if (dtLoguin.Rows[19][1].ToString() == "")
                        {
                            BtnQuitar20.Visible = false;
                        }
                        else
                        {
                            BtnQuitar20.Visible = true;
                            BtnAsignar20.Visible = false;
                            lblEspacio20.Text = dtLoguin.Rows[19]["Matricula_Vehi"].ToString();
                            lblIdVehiculo20.Text = dtLoguin.Rows[19]["id_ingre_sali"].ToString();
                        }
                    }

                }
            }
        }

        private void CargarUsuarios()
        {
            DataTable dtUsuarios = new DataTable();

            VigilanteBll objUsuariosBll = new VigilanteBll();

            dtUsuarios = objUsuariosBll.getMatriculaBll();
            DDLMatricula.DataSource = dtUsuarios;
            DDLMatricula.DataTextField = "Matricula_Vehi";
            DDLMatricula.DataValueField = "id_Vehi";
            DDLMatricula.DataBind();
        }

        private void Limpiar()
        {
            LblError.Text = "";
            lblSuccess.Text = "";
            LblErrorRestriccion.Text = "";
            lblSuccessRestriccion.Text = "";
            LblErrorSancion.Text = "";
            LblSuccessSancion.Text = "";
            alertError.Attributes.Add("style", "display:none");
            alertSuccess.Attributes.Add("style", "display:none");
        }

        protected void RYS_Click(object sender, EventArgs e)
        {
            Limpiar();
            DataTable dtVigilantes = new DataTable();
            //Crear e instanciamos un objeto de la clase MecanicosBll
            VigilanteBll oVigilantes = new VigilanteBll();
            //Llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
            dtVigilantes = oVigilantes.getEstadoRestriccionBll();

            if (dtVigilantes.Rows.Count > 0)
            {

                if (dtVigilantes.Rows[0][0].ToString() == "1")
                {
                    if (DDLMatricula.SelectedValue.EndsWith("2") | DDLMatricula.SelectedValue.EndsWith("4") | DDLMatricula.SelectedValue.EndsWith("6") | DDLMatricula.SelectedValue.EndsWith("8"))
                    {
                        alertError.Attributes.Add("style", "display:block");
                        LblErrorRestriccion.Text = "No se admiten placan que terminen en impar";

                    }
                    else
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccessRestriccion.Text = "Permitido";
                    }
                }
                else if (dtVigilantes.Rows[0][0].ToString() == "0")
                {
                    if (DDLMatricula.SelectedValue.EndsWith("1") | DDLMatricula.SelectedValue.EndsWith("3") | DDLMatricula.SelectedValue.EndsWith("5") | DDLMatricula.SelectedValue.EndsWith("7") | DDLMatricula.SelectedValue.EndsWith("9"))
                    {
                        alertError.Attributes.Add("style", "display:block");
                        LblErrorRestriccion.Text = "No se admiten placan que terminen en spar";
                    }
                    else
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccessRestriccion.Text = "Permitido";
                    }
                }

            }
            else
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Placa no registrada";

            }

            DataTable dtSanciones = new DataTable();
            //Crear e instanciamos un objeto de la clase MecanicosBll
            VigilanteBll oSanciones = new VigilanteBll();
            //Creamos la variable
            string Matricula = DDLMatricula.SelectedValue;
            //Llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
            dtSanciones = oSanciones.getSancionesClientesBll(Matricula);

            if (dtSanciones.Rows.Count > 0)
            {
                alertError.Attributes.Add("style", "display:block");
                LblErrorSancion.Text = "El cliente esta sancionado";
            }
            else
            {
                alertSuccess.Attributes.Add("style", "display:block");
                LblSuccessSancion.Text = "El cliente no tiene sanciones";

            }
        }

        protected void BtnRYS_Click(object sender, EventArgs e)
        {
            Limpiar();
            DataTable dtVigilantes = new DataTable();
            //Crear e instanciamos un objeto de la clase MecanicosBll
            VigilanteBll oVigilantes = new VigilanteBll();
            //Llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
            dtVigilantes = oVigilantes.getEstadoRestriccionBll();

            if (dtVigilantes.Rows.Count > 0)
            {

                if (dtVigilantes.Rows[0][0].ToString() == "1")
                {
                    if (DDLMatricula.SelectedValue.EndsWith("2") | DDLMatricula.SelectedValue.EndsWith("4") | DDLMatricula.SelectedValue.EndsWith("6") | DDLMatricula.SelectedValue.EndsWith("8"))
                    {
                        alertError.Attributes.Add("style", "display:block");
                        LblErrorRestriccion.Text = "No se admiten placan que terminen en impar";

                    }
                    else
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccessRestriccion.Text = "Permitido";
                    }
                }
                else if (dtVigilantes.Rows[0][0].ToString() == "0")
                {
                    if (DDLMatricula.SelectedValue.EndsWith("1") | DDLMatricula.SelectedValue.EndsWith("3") | DDLMatricula.SelectedValue.EndsWith("5") | DDLMatricula.SelectedValue.EndsWith("7") | DDLMatricula.SelectedValue.EndsWith("9"))
                    {
                        alertError.Attributes.Add("style", "display:block");
                        LblErrorRestriccion.Text = "No se admiten placan que terminen en spar";
                    }
                    else
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccessRestriccion.Text = "Permitido";
                    }
                }

            }
            else
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Placa no registrada";

            }

            DataTable dtSanciones = new DataTable();
            //Crear e instanciamos un objeto de la clase MecanicosBll
            VigilanteBll oSanciones = new VigilanteBll();
            //Creamos la variable
            string Matricula = DDLMatricula.SelectedValue;
            //Llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
            dtSanciones = oSanciones.getSancionesClientesBll(Matricula);

            if (dtSanciones.Rows.Count > 0)
            {
                alertError.Attributes.Add("style", "display:block");
                LblErrorSancion.Text = "El cliente esta sancionado";
            }
            else
            {
                alertSuccess.Attributes.Add("style", "display:block");
                LblSuccessSancion.Text = "El cliente no tiene sanciones";

            }
        }

        protected void BtnAsignar1_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar1.Visible = false;
                BtnQuitar1.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 1;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar1.Visible = true;
                    BtnQuitar1.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;
                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);
                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo1.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio1.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar1.Visible = true;
                BtnQuitar1.Visible = false;
            }
        }

        protected void BtnQuitar1_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar1.Visible = true;
                BtnQuitar1.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo1.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio1.Text = "1";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar1.Visible = false;
                BtnQuitar1.Visible = true;

            }
        }

        protected void BtnAsignar2_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar2.Visible = false;
                BtnQuitar2.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 2;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar2.Visible = true;
                    BtnQuitar2.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;
                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);
                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo2.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio2.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar2.Visible = true;
                BtnQuitar2.Visible = false;
            }
        }

        protected void BtnQuitar2_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar2.Visible = true;
                BtnQuitar2.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo2.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio2.Text = "2";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar2.Visible = false;
                BtnQuitar2.Visible = true;
            }
        }

        protected void BtnAsignar3_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar3.Visible = false;
                BtnQuitar3.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 3;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar3.Visible = true;
                    BtnQuitar3.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;
                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);
                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo3.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio3.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar3.Visible = true;
                BtnQuitar3.Visible = false;
            }
        }


        protected void BtnQuitar3_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar3.Visible = true;
                BtnQuitar3.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo3.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio3.Text = "3";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar3.Visible = false;
                BtnQuitar3.Visible = true;
            }
        }

        protected void BtnAsignar4_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar4.Visible = false;
                BtnQuitar4.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 4;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar4.Visible = true;
                    BtnQuitar4.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;
                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);
                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo4.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio4.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar4.Visible = true;
                BtnQuitar4.Visible = false;
            }
        }

        protected void BtnQuitar4_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar4.Visible = true;
                BtnQuitar4.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo4.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio4.Text = "4";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar4.Visible = false;
                BtnQuitar4.Visible = true;
            }
        }

        protected void BtnAsignar5_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar5.Visible = false;
                BtnQuitar5.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 5;


                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar5.Visible = true;
                    BtnQuitar5.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo5.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio5.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar5.Visible = true;
                BtnQuitar5.Visible = false;
            }
        }


        protected void BtnQuitar5_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar5.Visible = true;
                BtnQuitar5.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo5.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio5.Text = "5";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar5.Visible = false;
                BtnQuitar5.Visible = true;
            }
        }

        protected void BtnAsignar6_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar6.Visible = false;
                BtnQuitar6.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 6;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar6.Visible = true;
                    BtnQuitar6.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo6.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio6.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar6.Visible = true;
                BtnQuitar6.Visible = false;
            }
        }


        protected void BtnQuitar6_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar6.Visible = true;
                BtnQuitar6.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo6.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio6.Text = "6";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar6.Visible = false;
                BtnQuitar6.Visible = true;
            }
        }

        protected void BtnAsignar7_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar7.Visible = false;
                BtnQuitar7.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 7;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar7.Visible = true;
                    BtnQuitar7.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo7.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio7.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar7.Visible = true;
                BtnQuitar7.Visible = false;
            }
        }


        protected void BtnQuitar7_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar7.Visible = true;
                BtnQuitar7.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo7.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio7.Text = "7";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar7.Visible = false;
                BtnQuitar7.Visible = true;
            }
        }

        protected void BtnAsignar8_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar8.Visible = false;
                BtnQuitar8.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 8;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar8.Visible = true;
                    BtnQuitar8.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo8.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio8.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar8.Visible = true;
                BtnQuitar8.Visible = false;
            }
        }

        protected void BtnQuitar8_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar8.Visible = true;
                BtnQuitar8.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo8.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio8.Text = "8";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar8.Visible = false;
                BtnQuitar8.Visible = true;
            }
        }

        protected void BtnAsignar9_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar9.Visible = false;
                BtnQuitar9.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 9;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar9.Visible = true;
                    BtnQuitar9.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo9.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio9.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar9.Visible = true;
                BtnQuitar9.Visible = false;
            }
        }

        protected void BtnQuitar9_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar9.Visible = true;
                BtnQuitar9.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo9.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio9.Text = "9";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar9.Visible = false;
                BtnQuitar9.Visible = true;
            }
        }

        protected void BtnAsignar10_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar10.Visible = false;
                BtnQuitar10.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 10;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar10.Visible = true;
                    BtnQuitar10.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo10.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio10.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar10.Visible = true;
                BtnQuitar10.Visible = false;
            }
        }


        protected void BtnQuitar10_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar10.Visible = true;
                BtnQuitar10.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo10.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio10.Text = "10";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar10.Visible = false;
                BtnQuitar10.Visible = true;
            }
        }

        protected void BtnAsignar11_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar11.Visible = false;
                BtnQuitar11.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 11;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar11.Visible = true;
                    BtnQuitar11.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo11.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio11.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar11.Visible = true;
                BtnQuitar11.Visible = false;
            }
        }


        protected void BtnQuitar11_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar11.Visible = true;
                BtnQuitar11.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo11.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio11.Text = "11";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar11.Visible = false;
                BtnQuitar11.Visible = true;
            }
        }

        protected void BtnAsignar12_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar12.Visible = false;
                BtnQuitar12.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 12;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar12.Visible = true;
                    BtnQuitar12.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo12.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio12.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar12.Visible = true;
                BtnQuitar12.Visible = false;
            }
        }

        protected void BtnQuitar12_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar12.Visible = true;
                BtnQuitar12.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo12.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio12.Text = "12";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar12.Visible = false;
                BtnQuitar12.Visible = true;
            }
        }

        protected void BtnAsignar13_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar13.Visible = false;
                BtnQuitar13.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 13;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar13.Visible = true;
                    BtnQuitar13.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo13.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio13.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar13.Visible = true;
                BtnQuitar13.Visible = false;
            }
        }


        protected void BtnQuitar13_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar13.Visible = true;
                BtnQuitar13.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo13.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio13.Text = "13";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar13.Visible = false;
                BtnQuitar13.Visible = true;
            }
        }

        protected void BtnAsignar14_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar14.Visible = false;
                BtnQuitar14.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 14;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar14.Visible = true;
                    BtnQuitar14.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo14.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio14.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar14.Visible = true;
                BtnQuitar14.Visible = false;
            }
        }


        protected void BtnQuitar14_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar14.Visible = true;
                BtnQuitar14.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo14.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio14.Text = "14";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar14.Visible = false;
                BtnQuitar14.Visible = true;
            }
        }

        protected void BtnAsignar15_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar15.Visible = false;
                BtnQuitar15.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 15;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar15.Visible = true;
                    BtnQuitar15.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo15.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio15.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar15.Visible = true;
                BtnQuitar15.Visible = false;
            }
        }


        protected void BtnQuitar15_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar15.Visible = true;
                BtnQuitar15.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo15.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio15.Text = "15";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar15.Visible = false;
                BtnQuitar15.Visible = true;
            }
        }

        protected void BtnAsignar16_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar16.Visible = false;
                BtnQuitar16.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 16;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar16.Visible = true;
                    BtnQuitar16.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo16.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio16.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar16.Visible = true;
                BtnQuitar16.Visible = false;
            }
        }


        protected void BtnQuitar16_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar16.Visible = true;
                BtnQuitar16.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo16.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio16.Text = "16";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar16.Visible = false;
                BtnQuitar16.Visible = true;
            }
        }

        protected void BtnAsignar17_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar17.Visible = false;
                BtnQuitar17.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 17;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar17.Visible = true;
                    BtnQuitar17.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo17.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio17.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar17.Visible = true;
                BtnQuitar17.Visible = false;
            }
        }

        protected void BtnQuitar17_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar17.Visible = true;
                BtnQuitar17.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo17.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio17.Text = "17";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar17.Visible = false;
                BtnQuitar17.Visible = true;
            }
        }

        protected void BtnAsignar18_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar18.Visible = false;
                BtnQuitar18.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 18;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar18.Visible = true;
                    BtnQuitar18.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo18.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio18.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar18.Visible = true;
                BtnQuitar18.Visible = false;
            }
        }


        protected void BtnQuitar18_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar18.Visible = true;
                BtnQuitar18.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo18.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio18.Text = "18";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar18.Visible = false;
                BtnQuitar18.Visible = true;
            }
        }

        protected void BtnAsignar19_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar19.Visible = false;
                BtnQuitar19.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 19;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar19.Visible = true;
                    BtnQuitar19.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo19.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio19.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar19.Visible = true;
                BtnQuitar19.Visible = false;
            }
        }


        protected void BtnQuitar19_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar19.Visible = true;
                BtnQuitar19.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo19.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());

                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio19.Text = "19";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar19.Visible = false;
                BtnQuitar19.Visible = true;
            }
        }

        protected void BtnAsignar20_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar20.Visible = false;
                BtnQuitar20.Visible = true;
                Limpiar();

                DataTable dtUsuarios = new DataTable();
                DataTable dtVigilantes = new DataTable();
                DataTable dtValidacionV = new DataTable();

                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();
                VigilanteBll objVigilante = new VigilanteBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                DateTime Fecha_Ingreso = Convert.ToDateTime(DateTime.Now.ToString());
                int id_Vehiculo = int.Parse(DDLMatricula.SelectedValue);
                int Espacio = 20;

                dtValidacionV = objVigilante.ValidarVehiculoBll(id_Vehiculo);

                if (dtValidacionV.Rows.Count > 0)
                {
                    alertError.Attributes.Add("style", "display:block");
                    LblError.Text = "El vehiculo ya esta en el parqueadero";
                    BtnAsignar20.Visible = true;
                    BtnQuitar20.Visible = false;
                }
                else
                {
                    //Crear variable que retorna el resultado del query
                    string Retorno;

                    //invoco el metodo 
                    Retorno = oVigilantes.InsertarIngresoVehiculoBll(id_Vehiculo, Espacio);

                    //Valido si el registro se inserto correctamente
                    if (Retorno == "Ok")
                    {
                        alertSuccess.Attributes.Add("style", "display:block");
                        lblSuccess.Text = "Ingreso de vehiculo registrado";
                        lblSuccess.Visible = true;
                    }

                    dtVigilantes = oVigilantes.getIdIngresoBll(id_Vehiculo);

                    if (dtVigilantes.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblIdVehiculo20.Text = dtVigilantes.Rows[0]["id_ingre_sali"].ToString();
                    }

                    dtUsuarios = oVigilantes.getMatriculaParaLabelBll(id_Vehiculo);

                    if (dtUsuarios.Rows.Count > 0)
                    {
                        //llenar cada una de las cajas de texto xon los datos del mecanico encontrado
                        lblEspacio20.Text = dtUsuarios.Rows[0]["Matricula_Vehi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al ingresar el vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar20.Visible = true;
                BtnQuitar20.Visible = false;
            }
        }


        protected void BtnQuitar20_Click(object sender, EventArgs e)
        {
            try
            {
                BtnAsignar20.Visible = true;
                BtnQuitar20.Visible = false;
                Limpiar();
                //Crear e instanciamos un objeto de la clase 
                PruebaBll oVigilantes = new PruebaBll();

                //Creamos las variables para almacenar los valores y luego enviarlos como parametros
                int IdVehi = int.Parse(lblIdVehiculo20.Text);
                DateTime FechaSalida = Convert.ToDateTime(DateTime.Now.ToString());
                //Crear variable que retorna el resultado del query
                string Retorno;

                //invoco el metodo 
                Retorno = oVigilantes.UpdateSalidaParqueaderoBll(IdVehi);

                //Valido si el registro se inserto correctamente
                if (Retorno == "Ok")
                {
                    alertSuccess.Attributes.Add("style", "display:block");
                    lblSuccess.Text = "Salida de vehiculo registrada";
                    lblSuccess.Visible = true;
                    lblEspacio20.Text = "20";
                }
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "Se presentó un error al registrar la salida del vehiculo. Detaller Error: " + ex.Message.ToString();
                LblError.Visible = true;
                BtnAsignar20.Visible = false;
                BtnQuitar20.Visible = true;
            }
        }
    }
}