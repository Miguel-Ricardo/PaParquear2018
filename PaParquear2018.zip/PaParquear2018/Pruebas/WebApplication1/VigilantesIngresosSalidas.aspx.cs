﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Text;

namespace WebApplication1
{
    public partial class VigilantesIngresosSalidas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Int32 sesion = Convert.ToInt32(Session["SesionActiva"]);
                if (sesion != 1)
                {
                    Response.Redirect("Index.aspx", false);
                }

            }
            catch 
            {
                
                Response.Redirect("Index.aspx");
            }

            if (!IsPostBack)
            {
                CargarRestricciones();
                alertError.Attributes.Add("style", "display:none");
                BtnExportar.Attributes.Add("style", "display:none");
            }
        }

        private void CargarRestricciones()
        {
            DataTable dtOrden = new DataTable();

            VigilanteBll ovjMatriculas = new VigilanteBll();

            dtOrden = ovjMatriculas.getMatriculaBll();

            DDLPlacas.DataSource = dtOrden;
            DDLPlacas.DataTextField = "Matricula_Vehi";
            DDLPlacas.DataValueField = "id_Vehi";
            DDLPlacas.DataBind();
        }

        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                //llamo al metodo limpiar controles

                //LimpiarControles();
                //creamos el datatable para recibir la informacion 
                DataTable dtUsuarios = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();

                int Placa = int.Parse(DDLPlacas.SelectedValue);

                //llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
                dtUsuarios = objUsuariosBll.getIngresoByMatriculaBll(Placa);

                //seleccionamos el origen de datos para el datagriview
                GVIngresos.DataSource = dtUsuarios;
                GVIngresos.DataBind();
                BtnExportar.Attributes.Add("style", "display:block");
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "se presento un error al listar los registros :" + ex.Message.ToString();
            }
            finally
            {

            }
        }

        protected void BtnMostrarTodosr_Click(object sender, EventArgs e)
        {
            try
            {
                //llamo al metodo limpiar controles

                //LimpiarControles();
                //creamos el datatable para recibir la informacion 
                DataTable dtUsuarios = new DataTable();

                //creamos e instanciamos un objeto de la clase mecanicosBll
                AdministradorBll objUsuariosBll = new AdministradorBll();

                //llamamos la funcion que se encuentra en mecanicosBll que retorna el listado de los mecanicos
                dtUsuarios = objUsuariosBll.getAllIngresosBll();

                //seleccionamos el origen de datos para el datagriview
                GVIngresos.DataSource = dtUsuarios;
                GVIngresos.DataBind();
                BtnExportar.Attributes.Add("style", "display:block");
            }
            catch (Exception ex)
            {
                alertError.Attributes.Add("style", "display:block");
                LblError.Text = "se presento un error al listar los registros :" + ex.Message.ToString();
            }
            finally
            {

            }
        }

        protected void BtnExportar_Click(object sender, EventArgs e)
        {
            ExportToExcel("InformeIngresosSalidas.xls", GVIngresos);
        }

        private void ExportToExcel(string nameReport, GridView wControl)
        {
            HttpResponse response = Response;
            StringWriter sw = new StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);
            Page pageToRender = new Page();
            HtmlForm form = new HtmlForm();
            form.Controls.Add(wControl);
            pageToRender.Controls.Add(form);
            response.Clear();
            response.Buffer = true;
            response.ContentType = "application/vnd.ms-excel";
            response.AddHeader("Content-Disposition", "attachment;filename=" + nameReport);
            response.Charset = "UTF-8";
            response.ContentEncoding = Encoding.Default;
            pageToRender.RenderControl(htw);
            response.Write(sw.ToString());
            response.End();
        }
    }
}